package com.shinobiarts.client;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.network.MindInputPacket;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Mind Body Transfer, on the caster's side: the camera moves into the borrowed body's eyes and looks wherever the
 * mouse points; the movement keys, jump, attack and sneak (to leave) are sent to the server every tick, and none of
 * them move the caster's own (empty) body.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class MindTransferClient {
    private static int targetId = -1;
    private static boolean attackQueued;

    private MindTransferClient() {}

    public static void set(int target, int ticks) {
        Minecraft mc = Minecraft.getInstance();
        if (ticks <= 0) {
            clear();
            return;
        }
        targetId = target;
        if (mc.player != null) mc.player.displayClientMessage(Component.translatable("message.shinobiarts.mind_transfer_in"), true);
    }

    public static void clear() {
        Minecraft mc = Minecraft.getInstance();
        targetId = -1;
        attackQueued = false;
        if (mc.player != null && mc.getCameraEntity() != mc.player) mc.setCameraEntity(mc.player);
    }

    public static boolean active() {
        return targetId >= 0;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !active()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) {
            clear();
            return;
        }
        Entity body = mc.level.getEntity(targetId);
        if (body == null || !body.isAlive()) {
            if (mc.getCameraEntity() != mc.player) mc.setCameraEntity(mc.player);
            return;                                            // the server will end it
        }
        if (mc.getCameraEntity() != body) mc.setCameraEntity(body);
        if (mc.screen != null) return;
        var o = mc.options;
        float forward = (o.keyUp.isDown() ? 1f : 0f) - (o.keyDown.isDown() ? 1f : 0f);
        float strafe = (o.keyLeft.isDown() ? 1f : 0f) - (o.keyRight.isDown() ? 1f : 0f);
        ModNetwork.toServer(new MindInputPacket(forward, strafe, o.keyJump.isDown(), o.keyShift.isDown(), attackQueued,
                mc.player.getYRot(), mc.player.getXRot()));
        attackQueued = false;
        // the borrowed body looks where you look (until the server's own update arrives)
        body.setYRot(mc.player.getYRot());
        body.setXRot(mc.player.getXRot());
        body.setYHeadRot(mc.player.getYRot());
    }

    /** The view is the borrowed body's eyes, turned by your mouse. */
    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        Minecraft mc = Minecraft.getInstance();
        if (!active() || mc.player == null || mc.getCameraEntity() == mc.player) return;
        float partial = (float) event.getPartialTick();
        event.setYaw(mc.player.getViewYRot(partial));
        event.setPitch(mc.player.getViewXRot(partial));
    }

    /** Attacking hits with the borrowed body, not yours; using items does nothing. */
    @SubscribeEvent
    public static void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        if (!active()) return;
        if (event.isAttack()) attackQueued = true;
        event.setSwingHand(false);
        event.setCanceled(true);
    }

    /** Your own hand isn't there to see. */
    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (active()) event.setCanceled(true);
    }
}
