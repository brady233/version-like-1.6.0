package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.HashMap;
import java.util.Map;

/**
 * Water Prison: a sphere of translucent, swirling water around the trapped creature (two shells turning against each
 * other), with the white spiral of the current always facing you, and the caster holding it with an outstretched
 * arm. The sphere gathers out of nothing when the jutsu lands and bursts outward when it lets go.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class WaterPrisonRender {
    private static final ResourceLocation WATER = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/water_prison.png");
    private static final ResourceLocation WHITE = new ResourceLocation(ShinobiArts.MODID, "textures/entity/susanoo/white.png");
    private static final float FORM_TICKS = 6f, BURST_TICKS = 5f;

    /** The caster's arm held straight out toward the prison. */
    public static final HumanoidModel.ArmPose POSE = HumanoidModel.ArmPose.create("SHINOBIARTS_WATER_PRISON", false, (model, entity, arm) -> {
        ModelPart part = arm == HumanoidArm.RIGHT ? model.rightArm : model.leftArm;
        part.xRot = model.head.xRot - (Mth.PI / 2f);
        part.yRot = model.head.yRot + (arm == HumanoidArm.RIGHT ? -0.12f : 0.12f);
        part.zRot = 0f;
    });

    private record Prison(int targetId, float radius, long start, long end) {}

    private static final Map<Integer, Prison> PRISONS = new HashMap<>();

    private WaterPrisonRender() {}

    /** From the server: {@code casterId} holds {@code targetId} in a sphere of {@code radius} for {@code ticks} (0 = burst). */
    public static void set(int casterId, int targetId, int ticks, float radius) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        long now = mc.level.getGameTime();
        if (ticks <= 0) {
            Prison old = PRISONS.get(casterId);
            if (old != null) PRISONS.put(casterId, new Prison(old.targetId, old.radius, old.start, Math.min(old.end, now)));
            return;
        }
        PRISONS.put(casterId, new Prison(targetId, radius, now, now + ticks));
    }

    public static void clear() {
        PRISONS.clear();
    }

    /** Whether this player is holding someone in a Water Prison right now. */
    public static boolean isCaster(Player p) {
        return holding(p);
    }

    private static boolean holding(Player p) {
        Minecraft mc = Minecraft.getInstance();
        Prison pr = PRISONS.get(p.getId());
        return pr != null && mc.level != null && mc.level.getGameTime() < pr.end;
    }

    /** The caster's arm reaches out to the prison (after anything else that posed the arms). */
    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onRenderPlayer(RenderPlayerEvent.Pre event) {
        Player p = event.getEntity();
        if (!holding(p)) return;
        PlayerModel<AbstractClientPlayer> model = event.getRenderer().getModel();
        if (p.getMainArm() == HumanoidArm.RIGHT) model.rightArmPose = POSE;
        else model.leftArmPose = POSE;
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || PRISONS.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            PRISONS.clear();
            return;
        }
        float partial = event.getPartialTick();
        float now = mc.level.getGameTime() + partial;
        Vec3 cam = event.getCamera().getPosition();
        PoseStack ps = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f pose = ps.last().pose();
        Matrix3f normal = ps.last().normal();

        var it = PRISONS.entrySet().iterator();
        while (it.hasNext()) {
            Prison pr = it.next().getValue();
            if (now > pr.end + BURST_TICKS) {
                it.remove();
                continue;
            }
            Entity target = mc.level.getEntity(pr.targetId);
            if (target == null) continue;
            float grow = smooth(Mth.clamp((now - pr.start) / FORM_TICKS, 0f, 1f));
            float alpha = 1f, scale = 0.25f + 0.75f * grow + 0.06f * Mth.sin(Mth.clamp((now - pr.start) / FORM_TICKS, 0f, 1f) * Mth.PI);
            if (now > pr.end) {                                  // burst: swells and fades
                float b = Mth.clamp((now - pr.end) / BURST_TICKS, 0f, 1f);
                scale *= 1f + 0.35f * b;
                alpha = 1f - b;
            }
            if (alpha <= 0.01f) continue;
            Vec3 c = target.getPosition(partial).add(0, target.getBbHeight() / 2.0, 0);
            float r = pr.radius * scale;
            int light = LevelRenderer.getLightColor(mc.level, BlockPos.containing(c));
            light = Math.max(light & 0xFFFF, 0xA0) | (light & 0xFFFF0000);    // the water glows a little

            VertexConsumer water = buffers.getBuffer(RenderType.entityTranslucent(WATER));
            sphere(water, pose, normal, c, r * 0.96f, now * -0.011f, now * 2.2f, (int) (150 * alpha), light);
            sphere(water, pose, normal, c, r, now * 0.016f, now * -3.0f, (int) (215 * alpha), light);
            buffers.endBatch(RenderType.entityTranslucent(WATER));

            VertexConsumer white = buffers.getBuffer(RenderType.entityTranslucent(WHITE));
            spiral(white, pose, normal, c, cam, r, now, alpha, light);
            buffers.endBatch(RenderType.entityTranslucent(WHITE));
        }
        ps.popPose();
    }

    /** A textured sphere; {@code uScroll} turns the swirl around it, {@code tilt} wobbles its axis. */
    private static void sphere(VertexConsumer vc, Matrix4f pose, Matrix3f normal, Vec3 c, float r, float uScroll, float tilt,
                               int alpha, int light) {
        final int lat = 12, lon = 22;
        float ax = 0.25f * Mth.sin(tilt * Mth.DEG_TO_RAD), az = 0.25f * Mth.cos(tilt * Mth.DEG_TO_RAD);
        for (int i = 0; i < lat; i++) {
            float t0 = Mth.PI * i / lat, t1 = Mth.PI * (i + 1) / lat;
            for (int j = 0; j < lon; j++) {
                float p0 = Mth.TWO_PI * j / lon, p1 = Mth.TWO_PI * (j + 1) / lon;
                float u0 = j / (float) lon * 2f + uScroll, u1 = (j + 1) / (float) lon * 2f + uScroll;
                float v0 = i / (float) lat, v1 = (i + 1) / (float) lat;
                sv(vc, pose, normal, c, r, t0, p0, ax, az, u0, v0, alpha, light);
                sv(vc, pose, normal, c, r, t1, p0, ax, az, u0, v1, alpha, light);
                sv(vc, pose, normal, c, r, t1, p1, ax, az, u1, v1, alpha, light);
                sv(vc, pose, normal, c, r, t0, p1, ax, az, u1, v0, alpha, light);
            }
        }
    }

    private static void sv(VertexConsumer vc, Matrix4f pose, Matrix3f normal, Vec3 c, float r, float theta, float phi,
                           float ax, float az, float u, float v, int alpha, int light) {
        float nx = Mth.sin(theta) * Mth.cos(phi), ny = Mth.cos(theta), nz = Mth.sin(theta) * Mth.sin(phi);
        // tip the sphere's axis a little (the swirl runs at an angle)
        float x = nx + ax * ny, y = ny - ax * nx - az * nz, z = nz + az * ny;
        float len = Mth.sqrt(x * x + y * y + z * z);
        x /= len; y /= len; z /= len;
        vc.vertex(pose, (float) (c.x + x * r), (float) (c.y + y * r), (float) (c.z + z * r))
                .color(255, 255, 255, alpha).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light)
                .normal(normal, x, y, z).endVertex();
    }

    /** The white spiral of the current on the side facing you, turning. */
    private static void spiral(VertexConsumer vc, Matrix4f pose, Matrix3f normal, Vec3 c, Vec3 cam, float r, float now,
                               float alpha, int light) {
        Vec3 toCam = cam.subtract(c);
        if (toCam.lengthSqr() < 1e-4) return;
        toCam = toCam.normalize();
        Vec3 right = toCam.cross(new Vec3(0, 1, 0));
        if (right.lengthSqr() < 1e-4) right = new Vec3(1, 0, 0);
        right = right.normalize();
        Vec3 up = right.cross(toCam).normalize();
        Vec3 o = c.add(toCam.scale(r * 0.55));
        float maxR = r * 0.8f, spin = -now * 0.2f;
        int steps = 40;
        for (int arm = 0; arm < 3; arm++) {
            float base = spin + arm * Mth.TWO_PI / 3f;
            for (int i = 0; i < steps; i++) {
                float a0 = i / (float) steps, a1 = (i + 1) / (float) steps;
                float th0 = base + a0 * Mth.PI * 2.4f, th1 = base + a1 * Mth.PI * 2.4f;
                float rr0 = maxR * (0.12f + 0.88f * a0), rr1 = maxR * (0.12f + 0.88f * a1);
                float w0 = r * 0.05f * (1f - 0.6f * a0), w1 = r * 0.05f * (1f - 0.6f * a1);
                int al0 = (int) (alpha * 170 * Mth.sin(Mth.PI * Math.min(1f, a0 * 1.15f))), al1 = (int) (alpha * 170 * Mth.sin(Mth.PI * Math.min(1f, a1 * 1.15f)));
                Vec3 d0 = right.scale(Mth.cos(th0)).add(up.scale(Mth.sin(th0)));
                Vec3 d1 = right.scale(Mth.cos(th1)).add(up.scale(Mth.sin(th1)));
                Vec3 p0 = o.add(d0.scale(rr0)), p1 = o.add(d1.scale(rr1));
                ribbon(vc, pose, normal, p0.add(d0.scale(-w0)), p0.add(d0.scale(w0)), p1.add(d1.scale(w1)), p1.add(d1.scale(-w1)),
                        al0, al1, toCam, light);
            }
        }
    }

    private static void ribbon(VertexConsumer vc, Matrix4f pose, Matrix3f normal, Vec3 a, Vec3 b, Vec3 c, Vec3 d,
                               int alpha0, int alpha1, Vec3 n, int light) {
        rv(vc, pose, normal, a, alpha0, n, light);
        rv(vc, pose, normal, b, alpha0, n, light);
        rv(vc, pose, normal, c, alpha1, n, light);
        rv(vc, pose, normal, d, alpha1, n, light);
    }

    private static void rv(VertexConsumer vc, Matrix4f pose, Matrix3f normal, Vec3 p, int alpha, Vec3 n, int light) {
        vc.vertex(pose, (float) p.x, (float) p.y, (float) p.z).color(225, 245, 255, Math.max(0, alpha)).uv(0.5f, 0.5f)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(normal, (float) n.x, (float) n.y, (float) n.z).endVertex();
    }

    private static float smooth(float t) {
        return t * t * (3 - 2 * t);
    }
}
