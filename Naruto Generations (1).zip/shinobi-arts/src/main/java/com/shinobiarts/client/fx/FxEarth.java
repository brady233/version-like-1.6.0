package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.client.fx.FxDraw.Paint;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** Earth Release: the Earth Wall heaving up out of the ground before it sets. */
final class FxEarth {
    private FxEarth() {}

    /**
     * Earth Wall rising: a slab of earth {@code size} blocks wide (centred on a, running toward b) and 3 tall shoves up
     * out of the ground over six ticks, shedding clods; then the real wall is there.
     */
    static void rise(FxClient.Ctx c) {
        Vec3 a = c.fx().a;
        Vec3 side = c.fx().b.subtract(a);
        if (side.lengthSqr() < 1e-6) return;
        side = side.normalize();
        Vec3 fwd = new Vec3(-side.z, 0, side.x);
        float age = c.age();
        float up = FxDraw.smooth(age / 6f);
        float fade = 1f - Mth.clamp((age - 6f) / 2f, 0f, 1f);
        if (fade <= 0) return;
        float half = c.fx().size / 2f;
        Vec3 centre = a.add(0, -3 + 3 * up + 1.5, 0);
        Paint wall = FxDraw.block("minecraft:block/stone", 0xFFFFFF, fade);
        int light = FxDraw.lightAt(a.add(0, 1, 0));
        VertexConsumer vc = FxDraw.blocks(c.buffers());
        // the slab, made of block-sized pieces so the texture reads as earth (slightly uneven tops)
        for (int w = 0; w < Math.round(c.fx().size); w++) {
            float off = -half + 0.5f + w;
            float jag = (float) Math.sin((c.fx().seed + w) * 12.9898) * 0.12f;
            for (int h = 0; h < 3; h++) {
                Vec3 p = centre.add(side.scale(off)).add(0, -1 + h + jag * (h == 2 ? 1 : 0), 0);
                FxDraw.box(vc, c.ps(), p, side.scale(0.5), new Vec3(0, 0.5, 0), fwd.scale(0.5), wall, light);
            }
        }
    }
}
