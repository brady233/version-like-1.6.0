package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.client.fx.FxDraw.Paint;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * The genjutsu's crows, the Water Shark's explosion, the Medical Release (healing chakra, Cellular Activation, Poison
 * Mist) and the Rasenshuriken's sphere of wind blades.
 */
final class FxExtra {
    private FxExtra() {}

    private static final Vec3 UP = new Vec3(0, 1, 0);

    // ================================================================ crows

    /**
     * Genjutsu: where the caster stood, their body comes apart into a flock of crows that burst out and fly off away
     * from the target, flapping, with a few black feathers drifting down behind them.
     */
    static void crows(FxClient.Ctx c) {
        Vec3 o = c.fx().a;
        Vec3 away = c.fx().b.subtract(o);
        away = new Vec3(away.x, 0, away.z);
        away = away.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : away.normalize();
        Vec3 side = away.cross(UP).normalize();
        float age = c.age();
        int ticks = c.fx().ticks;
        float s = c.fx().size;
        RandomSource r = FxDraw.rng(c.fx().seed, 40);
        VertexConsumer vc = FxDraw.lit(c.buffers());
        int light = FxDraw.lightAt(o);
        Paint black = FxDraw.color(0x111116, 1f);
        for (int k = 0; k < 30; k++) {
            // they start packed into the shape of a body
            Vec3 start = o.add(side.scale(r.nextGaussian() * 0.22 * s)).add(0, (r.nextFloat() - 0.5) * 1.5 * s, 0)
                    .add(away.scale(r.nextGaussian() * 0.12 * s));
            float delay = r.nextFloat() * 4f;
            Vec3 dir = away.scale(0.8 + r.nextFloat() * 0.6).add(side.scale(r.nextGaussian() * 0.8)).add(0, 0.35 + r.nextFloat() * 0.7, 0).normalize();
            float speed = 0.22f + r.nextFloat() * 0.2f;
            float scale = (0.85f + r.nextFloat() * 0.4f) * s;
            float phase = r.nextFloat() * Mth.TWO_PI;
            float t = Math.max(0f, age - delay);
            float dist = speed * t + 0.006f * t * t;
            Vec3 pos = start.add(dir.scale(dist)).add(0, 0.08 * Mth.sin(t * 0.9f + phase), 0);
            float shrink = 1f - Mth.clamp((age - (ticks - 8)) / 8f, 0f, 1f);
            if (shrink <= 0.02f) continue;
            float flap = t <= 0 ? 0.2f : Mth.sin(age * 1.5f + phase) * 1.1f;
            crow(vc, c.ps(), pos, t <= 0 ? away : dir, flap, scale * shrink, black, light);
        }
        // a few feathers drifting down where they were
        for (int k = 0; k < 10; k++) {
            float delay = r.nextFloat() * 6;
            float t = Math.max(0, age - delay);
            Vec3 p = o.add(r.nextGaussian() * 0.5, 0.6 + r.nextFloat() * 0.6 - t * 0.03, r.nextGaussian() * 0.5)
                    .add(side.scale(0.15 * Mth.sin(t * 0.25f + k)));
            float fade = 1f - Mth.clamp(age / ticks, 0f, 1f);
            FxDraw.billboard(vc, c.ps(), c.camera(), p, 0.14f * s, 0.05f * s, t * 0.15f + k, FxDraw.color(0x15151A, fade), light);
        }
    }

    /** One crow, flying along {@code f}: body, head, beak, tail and two flapping wings. */
    private static void crow(VertexConsumer vc, PoseStack ps, Vec3 pos, Vec3 f, float flap, float s, Paint paint, int light) {
        Vec3 right = f.cross(UP);
        right = right.lengthSqr() < 1e-4 ? new Vec3(1, 0, 0) : right.normalize();
        Vec3 up = right.cross(f).normalize();
        FxDraw.box(vc, ps, pos, right.scale(0.055 * s), up.scale(0.055 * s), f.scale(0.13 * s), paint, light);
        Vec3 head = pos.add(f.scale(0.17 * s)).add(up.scale(0.03 * s));
        FxDraw.box(vc, ps, head, right.scale(0.042 * s), up.scale(0.042 * s), f.scale(0.045 * s), paint, light);
        Vec3 tip = head.add(f.scale(0.11 * s)).subtract(up.scale(0.01 * s));
        Vec3 b1 = head.add(f.scale(0.04 * s)).add(right.scale(0.02 * s)), b2 = head.add(f.scale(0.04 * s)).subtract(right.scale(0.02 * s));
        Paint beak = FxDraw.color(0x2A2A30, 1f);
        both(vc, ps, b1, tip, b2, b2, beak, light);
        Vec3 t1 = pos.subtract(f.scale(0.11 * s)), tailEnd = pos.subtract(f.scale(0.27 * s));
        both(vc, ps, t1.add(right.scale(0.03 * s)), tailEnd.add(right.scale(0.07 * s)), tailEnd.subtract(right.scale(0.07 * s)),
                t1.subtract(right.scale(0.03 * s)), paint, light);
        for (int sd = -1; sd <= 1; sd += 2) {
            Vec3 wing = right.scale(sd * Mth.cos(flap)).add(up.scale(Mth.sin(flap)));
            Vec3 rootF = pos.add(f.scale(0.07 * s)).add(right.scale(sd * 0.05 * s));
            Vec3 rootB = pos.subtract(f.scale(0.06 * s)).add(right.scale(sd * 0.05 * s));
            Vec3 elbow = rootF.add(wing.scale(0.16 * s)).add(f.scale(0.01 * s));
            Vec3 tipW = rootB.add(wing.scale(0.34 * s)).subtract(f.scale(0.1 * s));
            both(vc, ps, rootF, elbow, tipW, rootB, paint, light);
        }
    }

    /** A face drawn from both sides. */
    private static void both(VertexConsumer vc, PoseStack ps, Vec3 a, Vec3 b, Vec3 cc, Vec3 d, Paint paint, int light) {
        FxDraw.quad(vc, ps, a, b, cc, d, paint, light);
        FxDraw.quad(vc, ps, d, cc, b, a, paint, light);
    }

    // ================================================================ water

    /** The Water Shark exploding: a dome of water bursting out, a ring across the ground and spray falling back. */
    static void waterBurst(FxClient.Ctx c) {
        Vec3 o = c.fx().a;
        float age = c.age();
        int ticks = c.fx().ticks;
        float size = c.fx().size;
        float grow = FxDraw.smooth(Math.min(1f, age / 7f));
        float fade = 1f - FxDraw.smooth(Math.min(1f, age / ticks));
        int light = FxDraw.lightAt(o);
        VertexConsumer vc = FxDraw.lit(c.buffers());
        FxDraw.sphere(vc, c.ps(), o, size * (0.25f + 0.75f * grow), 12, 20, FxDraw.color(0x3A8CF0, 0.45f * fade), light);
        FxDraw.sphere(vc, c.ps(), o, size * (0.15f + 0.6f * grow), 10, 16, FxDraw.color(0xBFE6FF, 0.3f * fade), light);
        double ground = FxDraw.groundY(o.add(0, 0.5, 0)) + 0.05;
        FxDraw.ring(FxDraw.glow(c.buffers()), c.ps(), new Vec3(o.x, ground, o.z), UP, size * 1.3f * grow, size * 0.25f, 40,
                FxDraw.color(0xCFEFFF, 0.55f * fade), FxDraw.color(0x3A8CF0, 0f), light);
        RandomSource r = FxDraw.rng(c.fx().seed, 41);
        for (int k = 0; k < 70; k++) {                                // spray thrown out, then falling back
            Vec3 dir = new Vec3(r.nextGaussian(), Math.abs(r.nextGaussian()) + 0.4, r.nextGaussian()).normalize();
            float v = (0.25f + r.nextFloat() * 0.35f) * Math.max(1f, size / 4f);
            Vec3 p = o.add(dir.scale(v * age)).subtract(0, 0.03 * age * age, 0);
            if (p.y < ground) continue;
            float w = 0.12f + r.nextFloat() * 0.18f;
            FxDraw.billboard(vc, c.ps(), c.camera(), p, w, w * 1.6f, 0, FxDraw.color(0x9FD8FF, 0.8f * fade), light);
        }
    }

    // ================================================================ medical

    /** Poison Mist: a thick, slowly rolling violet fog, tinged a sickly green, that thins away at the end. */
    static void poisonMist(FxClient.Ctx c) {
        Vec3 centre = c.fx().a;
        float age = c.age();
        int ticks = c.fx().ticks;
        float radius = c.fx().size;
        float fade = Mth.clamp(age / 8f, 0f, 1f) * (1f - Mth.clamp((age - (ticks - 25)) / 25f, 0f, 1f));
        if (fade <= 0) return;
        VertexConsumer smoke = FxDraw.litTex(c.buffers(), FxYin.PUFF);
        RandomSource r = FxDraw.rng(c.fx().seed, 42);
        int light = FxDraw.lightAt(centre);
        float spread = Mth.clamp(0.4f + age / 20f, 0.4f, 1f);           // it billows out from where it was blown
        for (int k = 0; k < 46; k++) {
            Vec3 d = new Vec3(r.nextGaussian(), r.nextGaussian() * 0.45, r.nextGaussian()).normalize().scale(r.nextFloat() * radius * spread);
            float drift = age * 0.012f;
            Vec3 p = centre.add(d).add(Mth.sin(drift + k) * 0.4, 0.2 * Mth.sin(age * 0.04f + k), Mth.cos(drift * 1.3f + k) * 0.4);
            float s = (1.8f + r.nextFloat() * 1.8f) * Math.max(1f, radius / 4.5f);
            boolean green = r.nextInt(4) == 0;
            int rr = green ? 120 : 118 + r.nextInt(30), gg = green ? 150 : 52 + r.nextInt(20), bb = green ? 70 : 150 + r.nextInt(40);
            FxDraw.billboard(smoke, c.ps(), c.camera(), p, s, s, r.nextFloat() * 6 + age * 0.008f,
                    new Paint(0, 0, 1, 1, rr, gg, bb, Math.round(170 * fade)), light);
        }
    }

    /**
     * Healing Jutsu: green chakra glows on the healer's hands and flows in a stream into the patient, who is wrapped in
     * rising rings of green light.
     */
    static void heal(FxClient.Ctx c) {
        Entity healer = c.fx().entityA(), patient = c.fx().entityB();
        if (patient == null) return;
        float age = c.age();
        int ticks = c.fx().ticks;
        float fade = Mth.clamp(age / 4f, 0f, 1f) * (1f - Mth.clamp((age - (ticks - 8)) / 8f, 0f, 1f));
        VertexConsumer add = FxDraw.additive(c.buffers());
        Vec3 pc = patient.getPosition(c.partial()).add(0, patient.getBbHeight() * 0.5, 0);
        if (healer != null && healer != patient) {
            Vec3 h1 = FxLightning.hand(healer, c.partial(), true), h2 = FxLightning.hand(healer, c.partial(), false);
            for (Vec3 h : new Vec3[]{h1, h2}) {
                FxDraw.billboard(add, c.ps(), c.camera(), h, 0.55f, 0.55f, age * 0.05f, FxDraw.addColor(0x5EF08C, 0.55f * fade), FxDraw.FULL);
            }
            Vec3 from = h1.add(h2).scale(0.5);
            Vec3 dir = pc.subtract(from);
            Vec3 perp = FxDraw.perpendicular(dir.normalize());
            for (int strand = 0; strand < 3; strand++) {
                List<Vec3> pts = new ArrayList<>();
                for (int i = 0; i <= 16; i++) {
                    float u = i / 16f;
                    float wob = Mth.sin(u * 9f - age * 0.6f + strand * 2.1f) * 0.18f * Mth.sin(u * Mth.PI);
                    pts.add(from.add(dir.scale(u)).add(perp.scale(wob)).add(0, Mth.cos(u * 7f - age * 0.5f + strand) * 0.1 * Mth.sin(u * Mth.PI), 0));
                }
                FxDraw.ribbon(add, c.ps(), c.cam(), pts, 0.09f, 0.3f, FxDraw.addColor(0x8CFFB0, 0.6f * fade), FxDraw.addColor(0x3CE07A, 0.4f * fade), FxDraw.FULL);
            }
        }
        float w = patient.getBbWidth() * 0.75f + 0.2f;
        for (int k = 0; k < 3; k++) {
            float ph = ((age * 0.04f) + k / 3f) % 1f;
            Vec3 at = patient.getPosition(c.partial()).add(0, ph * patient.getBbHeight() * 1.1, 0);
            FxDraw.ring(FxDraw.glow(c.buffers()), c.ps(), at, UP, w, 0.12f, 32, FxDraw.color(0x7CFFA4, 0.55f * fade * Mth.sin(ph * Mth.PI)),
                    FxDraw.color(0x3CE07A, 0f), FxDraw.FULL);
        }
        FxDraw.billboard(add, c.ps(), c.camera(), pc, patient.getBbHeight() * 1.4f, patient.getBbHeight() * 1.4f, 0,
                FxDraw.addColor(0x3CE07A, 0.22f * fade), FxDraw.FULL);
    }

    /**
     * Cellular Activation: a pulsing green aura with a heartbeat, and small glowing cells dividing and rising around
     * the body for as long as it lasts.
     */
    static void cellActivation(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        float age = c.age();
        int ticks = c.fx().ticks;
        float fade = Mth.clamp(age / 6f, 0f, 1f) * (1f - Mth.clamp((age - (ticks - 20)) / 20f, 0f, 1f));
        Vec3 base = e.getPosition(c.partial());
        float h = e.getBbHeight();
        float beat = (age % 20f) / 20f;                               // a heartbeat every second
        float pulse = Math.max(0f, 1f - beat * 4f) + 0.6f * Math.max(0f, 1f - Math.abs(beat - 0.3f) * 6f);
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.billboard(add, c.ps(), c.camera(), base.add(0, h * 0.5, 0), h * 1.3f, h * 1.5f, 0,
                FxDraw.addColor(0x3CE07A, (0.16f + 0.18f * pulse) * fade), FxDraw.FULL);
        RandomSource r = FxDraw.rng(c.fx().seed, 43);
        for (int k = 0; k < 22; k++) {
            float speed = 0.02f + r.nextFloat() * 0.025f, ph = r.nextFloat();
            float t = (ph + age * speed) % 1f;
            float ang = r.nextFloat() * Mth.TWO_PI + age * 0.03f;
            float rad = e.getBbWidth() * 0.6f + 0.15f + r.nextFloat() * 0.2f;
            Vec3 p = base.add(Mth.cos(ang) * rad, t * h * 1.15f, Mth.sin(ang) * rad);
            float split = Mth.sin(t * Mth.PI);                         // a cell splitting in two as it rises
            float sz = 0.07f + 0.05f * split;
            Paint col = FxDraw.addColor(0x8CFFB0, 0.75f * fade * split);
            FxDraw.billboard(add, c.ps(), c.camera(), p.add(0, sz * 0.6 * split, 0), sz, sz, ang, col, FxDraw.FULL);
            FxDraw.billboard(add, c.ps(), c.camera(), p.subtract(0, sz * 0.6 * split, 0), sz, sz, -ang, col, FxDraw.FULL);
        }
        if (pulse > 0.5f) {
            FxDraw.ring(FxDraw.glow(c.buffers()), c.ps(), base.add(0, 0.05, 0), UP, e.getBbWidth() + 0.3f + beat * 3f, 0.15f, 32,
                    FxDraw.color(0x8CFFB0, 0.4f * fade * pulse), FxDraw.color(0x3CE07A, 0f), FxDraw.FULL);
        }
    }

    // ================================================================ Rasenshuriken

    /**
     * The Rasenshuriken detonating: its core swells into a huge, glowing sphere filled with thousands of tiny wind
     * blades whipping round inside it, then it thins away.
     */
    static void rasenSphere(FxClient.Ctx c) {
        Vec3 o = c.fx().a;
        float age = c.age();
        int ticks = c.fx().ticks;
        float size = c.fx().size;
        float grow = FxDraw.smooth(Math.min(1f, age / 9f));
        float fade = 1f - FxDraw.smooth(Mth.clamp((age - (ticks - 12)) / 12f, 0f, 1f));
        float r = size * (0.08f + 0.92f * grow);
        VertexConsumer add = FxDraw.additive(c.buffers());
        VertexConsumer glow = FxDraw.glow(c.buffers());
        FxDraw.sphere(glow, c.ps(), o, r, 16, 28, FxDraw.color(0xE6F6FF, 0.2f * fade), FxDraw.FULL);
        FxDraw.sphere(add, c.ps(), o, r * 0.97f, 16, 28, FxDraw.addColor(0x9CD8FF, 0.18f * fade), FxDraw.FULL);
        FxDraw.sphere(add, c.ps(), o, r * 0.45f, 12, 20, FxDraw.addColor(0xFFFFFF, 0.3f * fade), FxDraw.FULL);
        FxDraw.billboard(add, c.ps(), c.camera(), o, r * 2.8f, r * 2.8f, 0, FxDraw.addColor(0x8CCBFF, 0.25f * fade), FxDraw.FULL);
        RandomSource rnd = FxDraw.rng(c.fx().seed, 44);
        for (int k = 0; k < 70; k++) {                                // the wind blades whipping round inside
            Vec3 axis = new Vec3(rnd.nextGaussian(), rnd.nextGaussian(), rnd.nextGaussian()).normalize();
            Vec3 u = FxDraw.perpendicular(axis), v = axis.cross(u);
            float rr = r * (0.3f + 0.68f * rnd.nextFloat());
            float a0 = rnd.nextFloat() * Mth.TWO_PI + age * (0.35f + rnd.nextFloat() * 0.35f);
            List<Vec3> pts = new ArrayList<>();
            for (int i = 0; i <= 6; i++) {
                float a = a0 + i * 0.11f;
                pts.add(o.add(u.scale(Mth.cos(a) * rr)).add(v.scale(Mth.sin(a) * rr)));
            }
            FxDraw.ribbon(add, c.ps(), c.cam(), pts, Math.max(0.05f, r * 0.012f), 1f, FxDraw.addColor(0xFFFFFF, 0.75f * fade),
                    FxDraw.addColor(0xBDE6FF, 0f), FxDraw.FULL);
        }
        double ground = FxDraw.groundY(o.add(0, 0.5, 0)) + 0.06;
        if (Math.abs(ground - o.y) < r) {                             // where it meets the ground, a ring of torn-up air
            FxDraw.ring(glow, c.ps(), new Vec3(o.x, ground, o.z), UP, r * (1f + 0.15f * grow), r * 0.18f, 48,
                    FxDraw.color(0xFFFFFF, 0.45f * fade), FxDraw.color(0x9CD8FF, 0f), FxDraw.FULL);
        }
    }
}
