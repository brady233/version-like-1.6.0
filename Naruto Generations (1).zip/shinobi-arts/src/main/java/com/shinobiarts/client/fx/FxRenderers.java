package com.shinobiarts.client.fx;

import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/** Sends each effect to the code that draws it (one class per element). */
final class FxRenderers {
    private FxRenderers() {}

    static void render(FxClient.Ctx c) {
        switch (c.fx().type) {
            case GALE_PALM -> FxWind.galePalm(c);
            case VACUUM_BLADE -> FxWind.vacuumBlade(c);
            case BREAKTHROUGH -> FxWind.breakthrough(c);
            case CHIDORI -> FxLightning.chidori(c);
            case BOLT -> FxLightning.bolt(c);
            case THUNDER -> FxLightning.thunder(c);
            case EARTH_RISE -> FxEarth.rise(c);
            case HELL_VIEWING -> FxYin.hellViewing(c);
            case MIND_FOG -> FxYin.mindFog(c);
            case MYSTICAL_PALM -> FxYin.mysticalPalm(c);
            case VITALITY_BURST -> FxYin.vitalityBurst(c);
            case WOOD_BIND -> FxWood.bind(c);
            case FOREST -> FxWood.forest(c);
            case ICE_PRISON -> FxIce.prison(c);
            case ICE_MIRRORS -> FxIce.mirrors(c);
            case ICE_NEEDLE_FLY -> FxIce.needle(c);
            case ICE_SHATTER -> {
            }
            case IRON_RAIN -> FxMagnet.rain(c);
            case IRON_COFFIN -> FxMagnet.coffin(c);
            case IRON_WORLD -> FxMagnet.world(c);
            case BONE_FOREST -> FxBone.forest(c);
            case BARRIER -> FxSeal.barrier(c);
            case CHAINS -> FxSeal.chains(c);
            case FIVE_SEAL -> FxSeal.fiveSeal(c);
            case SHINRA -> FxRinnegan.shinra(c);
            case BANSHO -> FxRinnegan.bansho(c);
            case CHIBAKU -> FxRinnegan.chibaku(c);
            case ASH_CLOUD -> FxRinnegan.ash(c);
            case CROWS -> FxExtra.crows(c);
            case WATER_BURST -> FxExtra.waterBurst(c);
            case POISON_MIST -> FxExtra.poisonMist(c);
            case HEAL -> FxExtra.heal(c);
            case CELL_ACTIVATION -> FxExtra.cellActivation(c);
            case RASEN_SPHERE -> FxExtra.rasenSphere(c);
            case FIRE_DRAGON -> FxMore.fireDragon(c);
            case WIND_BULLET -> FxMore.windBullet(c);
            case SICKLE_WEASEL -> FxMore.sickleWeasel(c);
            case KIRIN -> FxMore.kirin(c);
            case BLACK_PANTHER -> FxMore.blackPanther(c);
            case FALSE_DARKNESS -> FxMore.falseDarkness(c);
            case LIGHTNING_HOUND -> FxMore.lightningHound(c);
            case EARTH_SPEAR -> FxMore.earthSpear(c);
            case EARTH_DRAGON -> FxMore.earthDragon(c);
            case MUD_BULLET -> FxMore.mudBullet(c);
            case EARTH_SANDWICH -> FxMore.earthSandwich(c);
            case ROCK_GOLEM -> FxMore.rockGolem(c);
            case MIST -> FxMore.mist(c);
            case BEAST_BOMB_CHARGE -> FxBeast.charge(c);
            case BEAST_BOMB -> FxBeast.bomb(c);
            case BEAST_BLAST -> FxBeast.blast(c);
            case BYAKUGAN_ON -> FxByakugan.awaken(c);
            case BYAKUGAN_SIGHT -> FxByakugan.sight(c);
            case GENTLE_FIST -> FxByakugan.gentleFist(c);
            case TRIGRAM_FIELD -> FxByakugan.trigramField(c);
            case PALM_FLURRY -> FxByakugan.palmFlurry(c);
            case PALM_FINISH -> FxByakugan.palmFinish(c);
            case AIR_PALM -> FxByakugan.airPalm(c);
            case PALM_ROTATION -> FxByakugan.rotation(c);
            case FLYING_THUNDER_GOD -> FxSpaceTime.flash(c);
            case TENGAI_METEOR -> FxRinnegan.meteor(c);
            case TENGAI_IMPACT -> FxRinnegan.meteorImpact(c);
            case LAVA_ROCK -> FxAdvanced.lavaRock(c);
            case QUICKLIME -> FxAdvanced.quicklime(c);
            case LIME_SHELL -> FxAdvanced.limeShell(c);
            case MELTING_APPARITION -> FxAdvanced.meltingApparition(c);
            case LASER_HALO -> FxAdvanced.laserHalo(c);
            case LASER_BEAM -> FxAdvanced.laserBeam(c);
            case STORM_CLOUD -> FxAdvanced.stormCloud(c);
            case STORM_BEAM -> FxAdvanced.stormBeam(c);
            case ACID_MIST -> FxAdvanced.acidMist(c);
            case STEAM_ARMOR -> FxAdvanced.steamArmor(c);
            case STEAM_BURST -> FxAdvanced.steamBurst(c);
            case SCORCH_ORB, SCORCH_LAUNCH -> FxAdvanced.scorchOrb(c);
            case SCORCH_ORBIT -> FxAdvanced.scorchOrbit(c);
        }
    }

    /** When an effect starts (one-off client particles). */
    static void started(FxClient.Active fx) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        RandomSource r = mc.level.random;
        if (fx.type == com.shinobiarts.fx.Fx.Visual.ICE_SHATTER) {          // the crystal breaking into glittering shards
            Vec3 p = fx.a;
            for (int i = 0; i < 40; i++) {
                mc.level.addParticle(ParticleTypes.SNOWFLAKE, p.x + r.nextGaussian() * 0.6, p.y + r.nextDouble() * fx.size, p.z + r.nextGaussian() * 0.6,
                        r.nextGaussian() * 0.15, r.nextDouble() * 0.2, r.nextGaussian() * 0.15);
            }
        }
    }

    /** Every tick while an effect plays (client particles that go with it). */
    static void tick(FxClient.Active fx, float age) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        RandomSource r = mc.level.random;
        switch (fx.type) {
            case CHIDORI -> {
                net.minecraft.world.entity.Entity e = fx.entityA();
                if (e != null && age < fx.ticks - 4) {
                    Vec3 h = FxLightning.hand(e, 1f, true);
                    mc.level.addParticle(ParticleTypes.ELECTRIC_SPARK, h.x, h.y, h.z, r.nextGaussian() * 0.25, r.nextGaussian() * 0.25, r.nextGaussian() * 0.25);
                }
            }
            case FOREST -> {
                if (age < 16 && r.nextInt(2) == 0) {
                    mc.level.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE, fx.a.x + r.nextGaussian() * 3, fx.a.y + 0.2, fx.a.z + r.nextGaussian() * 3, 0, 0.02, 0);
                }
            }
            case IRON_RAIN -> {
                if (r.nextInt(2) == 0) {
                    mc.level.addParticle(ParticleTypes.SMOKE, fx.a.x + r.nextGaussian() * 1.5, fx.a.y + 0.1, fx.a.z + r.nextGaussian() * 1.5, 0, 0.03, 0);
                }
            }
            default -> {
            }
        }
    }
}
