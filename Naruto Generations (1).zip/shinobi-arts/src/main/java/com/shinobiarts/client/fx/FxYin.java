package com.shinobiarts.client.fx;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.fx.FxDraw.Paint;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Yin and Yang Release: Hell Viewing (a dark vortex swallowing the victim's head), Mind Fog (a slow ring of illusion
 * fog), Mystical Palm (green healing chakra on the hands and over the patient) and Vitality Surge (a burst of golden
 * life force; the seal marks themselves are drawn on the body by SealMarksLayer).
 */
final class FxYin {
    static final ResourceLocation PUFF = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/cloud_puff.png");

    private FxYin() {}

    /** Hell Viewing: dark purple ribbons coil round the victim's head and shadows boil off it. */
    static void hellViewing(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        float age = c.age();
        float fade = Mth.clamp(age / 6f, 0f, 1f) * (1f - Mth.clamp((age - (c.fx().ticks - 10)) / 10f, 0f, 1f));
        Vec3 head = e.getPosition(c.partial()).add(0, e.getBbHeight() * 0.85, 0);
        VertexConsumer vc = FxDraw.glow(c.buffers());
        for (int k = 0; k < 3; k++) {
            List<Vec3> pts = new ArrayList<>();
            for (int i = 0; i <= 20; i++) {
                float t = i / 20f;
                float ang = age * 0.25f + k * Mth.TWO_PI / 3 + t * 5f;
                float r = 0.75f - t * 0.4f;
                pts.add(head.add(Mth.cos(ang) * r, (t - 0.5f) * 0.9f + 0.15f * Mth.sin(age * 0.2f + k), Mth.sin(ang) * r));
            }
            FxDraw.ribbon(vc, c.ps(), c.cam(), pts, 0.16f, 0.6f, FxDraw.color(0x3A0A4A, 0.85f * fade), FxDraw.color(0x8A2AB0, 0.2f * fade), FxDraw.FULL);
        }
        VertexConsumer smoke = FxDraw.litTex(c.buffers(), PUFF);
        RandomSource r = FxDraw.rng(c.fx().seed, 3);
        for (int k = 0; k < 8; k++) {
            float ph = (age * 0.05f + r.nextFloat()) % 1f;
            Vec3 p = head.add(r.nextGaussian() * 0.35, ph * 1.4 - 0.2, r.nextGaussian() * 0.35);
            FxDraw.billboard(smoke, c.ps(), c.camera(), p, 0.5f + ph, 0.5f + ph, r.nextFloat() * 6, new Paint(0, 0, 1, 1, 40, 20, 50,
                    Math.round(170 * fade * Mth.sin(ph * Mth.PI))), FxDraw.lightAt(p));
        }
    }

    /** Mind Fog: a wide, slowly turning ring of pale violet fog round the caster. */
    static void mindFog(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        Vec3 centre = e != null ? e.getPosition(c.partial()) : c.fx().a;
        float age = c.age();
        float fade = Mth.clamp(age / 10f, 0f, 1f) * (1f - Mth.clamp((age - (c.fx().ticks - 20)) / 20f, 0f, 1f));
        VertexConsumer vc = FxDraw.litTex(c.buffers(), PUFF);
        RandomSource r = FxDraw.rng(c.fx().seed, 4);
        float radius = c.fx().size;
        for (int k = 0; k < 46; k++) {
            float dist = 1.5f + r.nextFloat() * (radius - 1.5f);
            float ang = r.nextFloat() * Mth.TWO_PI + age * (0.012f + r.nextFloat() * 0.01f) * (k % 2 == 0 ? 1 : -1);
            float y = r.nextFloat() * 2.4f + 0.2f * Mth.sin(age * 0.05f + k);
            float size = 1.6f + r.nextFloat() * 1.8f;
            Vec3 p = centre.add(Mth.cos(ang) * dist, y, Mth.sin(ang) * dist);
            FxDraw.billboard(vc, c.ps(), c.camera(), p, size, size, r.nextFloat() * 6 + age * 0.004f,
                    new Paint(0, 0, 1, 1, 210, 200, 228, Math.round(95 * fade)), FxDraw.lightAt(p));
        }
    }

    /** Mystical Palm: green chakra glowing on both hands, and a green glow wrapped round the patient. */
    static void mysticalPalm(FxClient.Ctx c) {
        Entity caster = c.fx().entityA(), patient = c.fx().entityB();
        float age = c.age();
        float fade = Mth.clamp(age / 4f, 0f, 1f) * (1f - Mth.clamp((age - (c.fx().ticks - 8)) / 8f, 0f, 1f));
        VertexConsumer add = FxDraw.additive(c.buffers());
        float pulse = 0.8f + 0.2f * Mth.sin(age * 0.6f);
        if (caster != null) {
            for (boolean right : new boolean[]{true, false}) {
                Vec3 h = FxLightning.hand(caster, c.partial(), right);
                FxDraw.billboard(add, c.ps(), c.camera(), h, 0.8f * pulse, 0.8f * pulse, 0, FxDraw.addColor(0x3CFF7A, 0.55f * fade), FxDraw.FULL);
                FxDraw.billboard(add, c.ps(), c.camera(), h, 0.32f, 0.32f, 0, FxDraw.addColor(0xD8FFE4, 0.8f * fade), FxDraw.FULL);
            }
        }
        if (patient != null) {
            Vec3 mid = patient.getPosition(c.partial()).add(0, patient.getBbHeight() / 2, 0);
            float r = Math.max(patient.getBbWidth(), patient.getBbHeight()) * 0.6f;
            FxDraw.sphere(FxDraw.glow(c.buffers()), c.ps(), mid, r * pulse, 10, 16, FxDraw.color(0x50FF8A, 0.16f * fade), FxDraw.FULL);
            RandomSource rr = FxDraw.rng(c.fx().seed, 5);
            for (int k = 0; k < 12; k++) {
                float ph = (age * 0.04f + rr.nextFloat()) % 1f;
                Vec3 p = mid.add(rr.nextGaussian() * r * 0.6, (ph - 0.5) * r * 2, rr.nextGaussian() * r * 0.6);
                FxDraw.billboard(add, c.ps(), c.camera(), p, 0.12f, 0.12f, 0, FxDraw.addColor(0x9CFFB8, fade * Mth.sin(ph * Mth.PI)), FxDraw.FULL);
            }
        }
    }

    /** Vitality Surge: life force bursts out round the body in a golden-green ring and a rising column of light. */
    static void vitalityBurst(FxClient.Ctx c) {
        Entity e = c.fx().entityA();
        if (e == null) return;
        Vec3 feet = e.getPosition(c.partial());
        float age = c.age();
        float t = age / c.fx().ticks;
        float fade = 1f - FxDraw.smooth(t);
        VertexConsumer add = FxDraw.additive(c.buffers());
        FxDraw.ring(add, c.ps(), feet.add(0, 0.05, 0), new Vec3(0, 1, 0), 0.6f + t * 4f, 0.5f, 40, FxDraw.addColor(0xFFE27A, 0.8f * fade),
                FxDraw.addColor(0x9AFF6A, 0f), FxDraw.FULL);
        for (int k = 0; k < 10; k++) {
            float ang = k * Mth.TWO_PI / 10 + age * 0.15f;
            List<Vec3> pts = new ArrayList<>();
            for (int i = 0; i <= 8; i++) {
                float y = i / 8f * 2.6f * (0.4f + t);
                pts.add(feet.add(Mth.cos(ang + y * 0.8f) * 0.6f, y, Mth.sin(ang + y * 0.8f) * 0.6f));
            }
            FxDraw.ribbon(add, c.ps(), c.cam(), pts, 0.14f, 0.8f, FxDraw.addColor(0xFFF1A0, 0.7f * fade), FxDraw.addColor(0x7CFF8A, 0f), FxDraw.FULL);
        }
    }
}
