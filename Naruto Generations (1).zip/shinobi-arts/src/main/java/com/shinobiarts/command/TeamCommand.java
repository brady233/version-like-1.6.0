package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.shinobiarts.combat.Vault;
import com.shinobiarts.team.TeamManager;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.BiFunction;

/** /team (create, invite, accept, decline, leave, kick, disband, info) and /vault. Open to every player. */
public final class TeamCommand {
    private TeamCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("team")
                .executes(ctx -> run(ctx, (m, p) -> m.info(p)))
                .then(Commands.literal("info").executes(ctx -> run(ctx, (m, p) -> m.info(p))))
                .then(Commands.literal("create").then(Commands.argument("name", StringArgumentType.word())
                        .executes(ctx -> run(ctx, (m, p) -> m.create(p, StringArgumentType.getString(ctx, "name"))))))
                .then(Commands.literal("invite").then(Commands.argument("player", EntityArgument.player())
                        .executes(ctx -> {
                            ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                            return run(ctx, (m, p) -> m.invite(p, target));
                        })))
                .then(Commands.literal("accept").executes(ctx -> run(ctx, (m, p) -> m.accept(p))))
                .then(Commands.literal("decline").executes(ctx -> run(ctx, (m, p) -> m.decline(p))))
                .then(Commands.literal("leave").executes(ctx -> run(ctx, (m, p) -> m.leave(p))))
                .then(Commands.literal("kick").then(Commands.argument("name", StringArgumentType.word())
                        .executes(ctx -> run(ctx, (m, p) -> m.kick(p, StringArgumentType.getString(ctx, "name"))))))
                .then(Commands.literal("disband").executes(ctx -> run(ctx, (m, p) -> m.disband(p)))));

        dispatcher.register(Commands.literal("vault").executes(ctx -> {
            Vault.open(ctx.getSource().getPlayerOrException());
            return 1;
        }));
    }

    private static int run(CommandContext<CommandSourceStack> ctx, BiFunction<TeamManager, ServerPlayer, Component> action)
            throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        Component message = action.apply(TeamManager.get(player.server), player);
        if (!message.getString().isEmpty()) player.sendSystemMessage(message);
        return 1;
    }
}
