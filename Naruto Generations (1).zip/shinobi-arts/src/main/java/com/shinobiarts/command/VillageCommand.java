package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.quest.QuestBoard;
import com.shinobiarts.village.VillageManager;
import com.shinobiarts.village.Villages;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;

/**
 * /village               your village's quest board
 * /village &lt;village&gt;     the same (you must belong to it)
 * /village &lt;village&gt; admin   the Kage menu
 * /village list          every village
 * Admins: /shinobi village &lt;player&gt; &lt;village|none&gt;, /shinobi kage &lt;player&gt; &lt;village|none&gt;
 * (used when permissions don't place a player).
 */
public final class VillageCommand {
    private static final SuggestionProvider<CommandSourceStack> VILLAGES = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Villages.all().stream().map(Villages.Village::id), builder);
    private static final SuggestionProvider<CommandSourceStack> VILLAGES_OR_NONE = (ctx, builder) ->
            SharedSuggestionProvider.suggest(java.util.stream.Stream.concat(Villages.all().stream().map(Villages.Village::id),
                    java.util.stream.Stream.of("none")), builder);

    private VillageCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("village")
                .executes(ctx -> board(ctx, null, false))
                .then(Commands.literal("list").executes(VillageCommand::list))
                .then(Commands.argument("village", StringArgumentType.word()).suggests(VILLAGES)
                        .executes(ctx -> board(ctx, StringArgumentType.getString(ctx, "village"), false))
                        .then(Commands.literal("admin").executes(ctx -> board(ctx, StringArgumentType.getString(ctx, "village"), true)))));

        dispatcher.register(Commands.literal("shinobi")
                .then(Commands.literal("village").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("village", StringArgumentType.word()).suggests(VILLAGES_OR_NONE)
                                        .executes(ctx -> assign(ctx, false)))))
                .then(Commands.literal("kage").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("village", StringArgumentType.word()).suggests(VILLAGES_OR_NONE)
                                        .executes(ctx -> assign(ctx, true)))))
                .then(Commands.literal("advisor").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("village", StringArgumentType.word()).suggests(VILLAGES_OR_NONE)
                                        .executes(VillageCommand::advisor)))));
    }

    private static int board(CommandContext<CommandSourceStack> ctx, String village, boolean admin) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        VillageManager.refresh(player);
        NinjaData d = NinjaData.get(player);
        if (d == null) return 0;
        if (village != null && !village.equalsIgnoreCase(d.getVillage())) {
            if (Villages.byId(village.toLowerCase(java.util.Locale.ROOT)) == null) {
                ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.unknown_village", village));
            } else {
                ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.not_member", Villages.name(village.toLowerCase(java.util.Locale.ROOT))));
            }
            return 0;
        }
        QuestBoard.open(player, admin);
        return 1;
    }

    private static int list(CommandContext<CommandSourceStack> ctx) {
        MutableComponent msg = Component.translatable("message.shinobiarts.village_list").withStyle(ChatFormatting.GOLD);
        for (Villages.Village v : Villages.all()) {
            msg.append(Component.literal("\n " + v.name() + " (" + v.id() + ")").withStyle(ChatFormatting.WHITE));
        }
        ctx.getSource().sendSuccess(() -> msg, false);
        return 1;
    }

    /** /shinobi advisor &lt;player&gt; &lt;village|none&gt;: appoints (or removes) a Village Advisor. */
    private static int advisor(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        String village = StringArgumentType.getString(ctx, "village").toLowerCase(java.util.Locale.ROOT);
        NinjaData d = NinjaData.get(player);
        if (d == null) return 0;
        if (!village.equals("none") && Villages.byId(village) == null) {
            ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.unknown_village", village));
            return 0;
        }
        d.setAdvisorOf(village.equals("none") ? "" : village);
        VillageManager.refresh(player);
        String name = player.getGameProfile().getName();
        ctx.getSource().sendSuccess(() -> Component.literal(name + (d.isAdvisor() ? " is now a Village Advisor of " + Villages.name(d.getVillage())
                : village.equals("none") ? " is no longer a Village Advisor" : " will be an Advisor once they're in " + Villages.name(village))), true);
        if (d.isAdvisor()) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.you_advisor", Villages.name(d.getVillage())).withStyle(ChatFormatting.AQUA));
        }
        return 1;
    }

    private static int assign(CommandContext<CommandSourceStack> ctx, boolean kage) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        String village = StringArgumentType.getString(ctx, "village").toLowerCase(java.util.Locale.ROOT);
        NinjaData d = NinjaData.get(player);
        if (d == null) return 0;
        if (village.equals("none")) {
            d.setAssignment(kage ? d.getAssignedVillage() : "", false);
        } else if (Villages.byId(village) == null) {
            ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.unknown_village", village));
            return 0;
        } else {
            d.setAssignment(village, kage || (d.isAssignedKage() && village.equals(d.getAssignedVillage())));
        }
        VillageManager.refresh(player);
        ModNetwork.sync(player);
        String name = player.getGameProfile().getName();
        ctx.getSource().sendSuccess(() -> Component.literal(name + ": " + (d.getVillage().isEmpty() ? "no village" : Villages.name(d.getVillage()))
                + (d.isKage() ? " (Kage)" : "")), true);
        return 1;
    }
}
