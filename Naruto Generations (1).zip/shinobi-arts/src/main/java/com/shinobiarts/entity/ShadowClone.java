package com.shinobiarts.entity;

import com.shinobiarts.jutsu.JutsuEffects;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.registry.ModDamage;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.Optional;
import java.util.UUID;

/**
 * A solid copy of its owner. Wears the owner's skin and gear, follows them, fights whatever they
 * fight, and disappears in a puff of smoke after 30 seconds or the moment it takes any hit.
 */
public class ShadowClone extends PathfinderMob {
    private static final EntityDataAccessor<Optional<UUID>> OWNER = SynchedEntityData.defineId(ShadowClone.class, EntityDataSerializers.OPTIONAL_UUID);
    /** Sharingan stage on the clone's face (copied from the owner while the owner's eyes are on). */
    private static final EntityDataAccessor<Byte> EYES = SynchedEntityData.defineId(ShadowClone.class, EntityDataSerializers.BYTE);
    /** The hand jutsu the clone is holding, copied from its owner. */
    private static final EntityDataAccessor<Byte> HAND = SynchedEntityData.defineId(ShadowClone.class, EntityDataSerializers.BYTE);
    /** A Water Clone (made of water: a wet sheen, bursts into a splash). */
    private static final EntityDataAccessor<Boolean> WATER = SynchedEntityData.defineId(ShadowClone.class, EntityDataSerializers.BOOLEAN);
    public static final int LIFETIME = 600;
    private static final DustParticleOptions RASENGAN_DUST = new DustParticleOptions(new Vector3f(0.55f, 0.85f, 1.0f), 0.8f);
    private static final DustParticleOptions WIND_DUST = new DustParticleOptions(new Vector3f(0.9f, 0.97f, 1.0f), 0.9f);

    /** Jutsu held in the hand that clones copy from their owner (add new hand jutsu here). */
    public enum HandJutsu { NONE, RASENGAN, CHIDORI, RASENSHURIKEN }

    private int life = LIFETIME;
    private int ownerMissingTicks;
    private int handTicks;

    public ShadowClone(EntityType<? extends ShadowClone> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 2.0)
                .add(Attributes.MOVEMENT_SPEED, 0.32)
                .add(Attributes.ATTACK_DAMAGE, 3.0)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(OWNER, Optional.empty());
        this.entityData.define(EYES, (byte) 0);
        this.entityData.define(HAND, (byte) 0);
        this.entityData.define(WATER, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.3, true));
        this.goalSelector.addGoal(2, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Monster.class, 5, true, false,
                target -> !(target instanceof Creeper)));
    }

    // ---------------------------------------------------------------- owner

    public boolean isWater() {
        return this.entityData.get(WATER);
    }

    public void setWater(boolean water) {
        this.entityData.set(WATER, water);
    }

    public void setOwner(Player owner) {
        this.entityData.set(OWNER, Optional.of(owner.getUUID()));
    }

    @Nullable
    public UUID getOwnerUUID() {
        return this.entityData.get(OWNER).orElse(null);
    }

    @Nullable
    public Player getOwner() {
        UUID id = getOwnerUUID();
        return id == null ? null : level().getPlayerByUUID(id);
    }

    private boolean isFriendly(Entity other) {
        UUID id = getOwnerUUID();
        if (id == null) return false;
        if (id.equals(other.getUUID())) return true;
        return other instanceof ShadowClone clone && id.equals(clone.getOwnerUUID());
    }

    @Override
    public boolean isAlliedTo(Entity other) {
        return isFriendly(other) || super.isAlliedTo(other);
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        return !isFriendly(target) && super.canAttack(target);
    }

    /** Copies the owner's held items and armor (cosmetic + weapon damage; never dropped). */
    public void copyEquipment(Player owner) {
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            setItemSlot(slot, owner.getItemBySlot(slot).copy());
            setDropChance(slot, 0.0f);
        }
    }

    // ---------------------------------------------------------------- copied eyes and hand jutsu

    /** The clone's eyes: the Sharingan stage and Mangekyou pattern, packed like SharinganManager.look. */
    public int getEyesLook() {
        return this.entityData.get(EYES) & 31;
    }

    public int getEyesStage() {
        return SharinganManager.lookStage(getEyesLook());
    }

    public HandJutsu getHandJutsu() {
        int i = this.entityData.get(HAND);
        return HandJutsu.values()[Math.max(0, Math.min(HandJutsu.values().length - 1, i))];
    }

    public void giveHandJutsu(HandJutsu jutsu, int ticks) {
        this.entityData.set(HAND, (byte) jutsu.ordinal());
        handTicks = jutsu == HandJutsu.NONE ? 0 : ticks;
    }

    /** The owner just cast a jutsu: every one of their clones nearby copies it if it's a hand jutsu. */
    public static void copyOwnerJutsu(ServerPlayer owner, String jutsuId) {
        HandJutsu hand = switch (jutsuId) {
            case "rasengan" -> HandJutsu.RASENGAN;
            case "chidori" -> HandJutsu.CHIDORI;
            case "rasenshuriken" -> HandJutsu.RASENSHURIKEN;
            default -> HandJutsu.NONE;
        };
        if (hand == HandJutsu.NONE) return;
        for (ShadowClone clone : owner.serverLevel().getEntitiesOfClass(ShadowClone.class, owner.getBoundingBox().inflate(64),
                c -> owner.getUUID().equals(c.getOwnerUUID()))) {
            clone.giveHandJutsu(hand, 200);
        }
    }

    /** Uses the held hand jutsu on the current target: Rasengan up close or thrown, Chidori dash, Rasenshuriken throw. */
    private void useHandJutsu(@Nullable Player owner) {
        HandJutsu hand = getHandJutsu();
        if (hand == HandJutsu.NONE) return;
        if (--handTicks <= 0) {
            giveHandJutsu(HandJutsu.NONE, 0);
            return;
        }
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive() || !(level() instanceof ServerLevel level)) return;
        double dist = distanceTo(target);
        boolean sight = hasLineOfSight(target);
        Entity credit = owner != null ? owner : this;
        switch (hand) {
            case RASENGAN -> {
                if (dist <= 2.6) {
                    target.hurt(ModDamage.jutsu(level, this, credit), JutsuUtil.dmg(14f) * JutsuUtil.upgradeBonus(owner, "rasengan"));
                    JutsuEffects.rasenganHit(this, target);
                    swing(InteractionHand.MAIN_HAND);
                    giveHandJutsu(HandJutsu.NONE, 0);
                } else if (dist >= 4.0 && dist <= 18.0 && sight) {
                    JutsuProjectile.shootAt(this, owner, JutsuProjectile.Kind.RASENGAN, 1.5f, JutsuUtil.dmg(12f) * JutsuUtil.upgradeBonus(owner, "rasengan"), target);
                    swing(InteractionHand.MAIN_HAND);
                    giveHandJutsu(HandJutsu.NONE, 0);
                }
            }
            case CHIDORI -> {
                if (dist <= 14.0 && sight) {
                    Vec3 start = getBoundingBox().getCenter();
                    Vec3 dir = target.position().subtract(position()).multiply(1, 0, 1);
                    dir = dir.lengthSqr() < 1e-4 ? getLookAngle().multiply(1, 0, 1) : dir.normalize();
                    Vec3 safe = JutsuUtil.findSafe(this, target.position().subtract(dir.scale(target.getBbWidth() / 2 + 0.9)));
                    if (safe != null) JutsuUtil.teleport(this, safe);
                    target.hurt(ModDamage.jutsu(level, this, credit), JutsuUtil.dmg(16f) * JutsuUtil.upgradeBonus(owner, "chidori"));
                    JutsuUtil.push(target, dir.scale(1.4).add(0, 0.4, 0));
                    JutsuUtil.line(level, ParticleTypes.ELECTRIC_SPARK, start, target.getBoundingBox().getCenter(), 0.4, 3, 0.15);
                    JutsuUtil.particles(level, ParticleTypes.ELECTRIC_SPARK, target.getBoundingBox().getCenter(), 40, 0.5, 0.4);
                    JutsuUtil.sound(level, position(), SoundEvents.TRIDENT_THUNDER, 0.6f, 1.6f);
                    swing(InteractionHand.MAIN_HAND);
                    giveHandJutsu(HandJutsu.NONE, 0);
                }
            }
            case RASENSHURIKEN -> {
                if (dist <= 24.0 && sight) {
                    JutsuProjectile.shootAt(this, owner, JutsuProjectile.Kind.RASENSHURIKEN, 1.0f, JutsuUtil.dmg(14f) * JutsuUtil.upgradeBonus(owner, "rasenshuriken"), target);
                    JutsuUtil.sound(level, position(), SoundEvents.ELYTRA_FLYING, 0.8f, 1.8f);
                    swing(InteractionHand.MAIN_HAND);
                    giveHandJutsu(HandJutsu.NONE, 0);
                }
            }
            default -> {
            }
        }
    }

    /** Client: Chidori crackles in the clone's right hand (a Rasengan or Rasenshuriken is drawn by ShadowCloneRenderer). */
    private void handParticles() {
        HandJutsu hand = getHandJutsu();
        if (hand == HandJutsu.NONE) return;
        double yaw = Math.toRadians(yBodyRot);
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double hx = getX() + fx * 0.45 - fz * 0.38, hy = getY() + 1.0, hz = getZ() + fz * 0.45 + fx * 0.38;
        switch (hand) {
            case CHIDORI -> level().addParticle(ParticleTypes.ELECTRIC_SPARK, hx, hy, hz,
                    (random.nextDouble() - 0.5) * 0.3, (random.nextDouble() - 0.5) * 0.3, (random.nextDouble() - 0.5) * 0.3);
            default -> {
            }
        }
    }

    // ---------------------------------------------------------------- behaviour

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            handParticles();
            return;
        }
        if (isRemoved()) return;
        if (--life <= 0) {
            poof();
            return;
        }
        Player owner = getOwner();
        if (owner == null || !owner.isAlive()) {
            if (++ownerMissingTicks > 40) poof();
            return;
        }
        ownerMissingTicks = 0;
        if (tickCount % 10 == 0) followOwnersFight(owner);
        if (tickCount % 5 == 0) copyOwnerEyes(owner);
        useHandJutsu(owner);
    }

    /** The clone's eyes match the owner's Sharingan, but only while the owner has it switched on. */
    private void copyOwnerEyes(Player owner) {
        NinjaData data = NinjaData.get(owner);
        int look = data != null && data.isSharinganActive()
                ? SharinganManager.packEyes(data.activeSharinganStage(), data.getMangekyouDesign()) : 0;
        if (look != getEyesLook()) this.entityData.set(EYES, (byte) look);
    }

    private void followOwnersFight(Player owner) {
        LivingEntity hit = owner.getLastHurtMob();
        if (hit != null && hit.isAlive() && hit != this && !isFriendly(hit)
                && owner.tickCount - owner.getLastHurtMobTimestamp() < 100) {
            if (getTarget() != hit) setTarget(hit);
            return;
        }
        LivingEntity attacker = owner.getLastHurtByMob();
        if (attacker != null && attacker.isAlive() && attacker != this && !isFriendly(attacker) && getTarget() != attacker) {
            setTarget(attacker);
        }
    }

    /** Any hit dispels the clone, unless its copied Sharingan sees the hit coming. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || isRemoved()) return false;
        if (isInvulnerableTo(source)) return false;
        if (getEyesStage() > 0 && !source.is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY)
                && random.nextFloat() < SharinganManager.dodgeChance(getEyesStage(), 1f)) {
            if (level() instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.CRIT, getX(), getY() + 1, getZ(), 10, 0.3, 0.5, 0.3, 0.1);
            }
            playSound(SoundEvents.PLAYER_ATTACK_NODAMAGE, 1.0f, 1.4f);
            return false;
        }
        poof();
        return true;
    }

    public void poof() {
        if (level() instanceof ServerLevel server) {
            if (isWater()) {                                  // a water clone bursts into a splash
                server.sendParticles(ParticleTypes.SPLASH, getX(), getY() + 1.0, getZ(), 80, 0.4, 0.8, 0.4, 0.2);
                server.sendParticles(ParticleTypes.FALLING_WATER, getX(), getY() + 1.0, getZ(), 30, 0.4, 0.8, 0.4, 0.0);
                server.playSound(null, getX(), getY(), getZ(), SoundEvents.PLAYER_SPLASH_HIGH_SPEED, SoundSource.NEUTRAL, 0.8f, 1.2f);
            } else {
                server.sendParticles(ParticleTypes.POOF, getX(), getY() + 1.0, getZ(), 25, 0.3, 0.6, 0.3, 0.03);
                server.playSound(null, getX(), getY(), getZ(), com.shinobiarts.registry.ModSounds.CLONE_POOF.get(), SoundSource.NEUTRAL, 0.8f, 1.0f);
            }
        }
        discard();
    }

    void teleportNear(Player owner) {
        double x = owner.getX() + (random.nextDouble() - 0.5) * 3.0;
        double z = owner.getZ() + (random.nextDouble() - 0.5) * 3.0;
        teleportTo(x, owner.getY(), z);
        getNavigation().stop();
    }

    @Override
    public boolean removeWhenFarAway(double distanceSqr) {
        return false;
    }

    @Override
    protected boolean shouldDropLoot() {
        return false;
    }

    // ---------------------------------------------------------------- save

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        UUID id = getOwnerUUID();
        if (id != null) tag.putUUID("Owner", id);
        tag.putInt("Life", life);
        tag.putBoolean("Water", isWater());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) this.entityData.set(OWNER, Optional.of(tag.getUUID("Owner")));
        if (tag.contains("Life")) life = tag.getInt("Life");
        setWater(tag.getBoolean("Water"));
    }

    // ---------------------------------------------------------------- goals

    static class FollowOwnerGoal extends Goal {
        private final ShadowClone clone;
        @Nullable
        private Player owner;
        private int recalc;

        FollowOwnerGoal(ShadowClone clone) {
            this.clone = clone;
            setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            Player o = clone.getOwner();
            if (o == null || o.isSpectator() || clone.getTarget() != null) return false;
            if (clone.distanceToSqr(o) < 16.0) return false;
            owner = o;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return owner != null && owner.isAlive() && clone.getTarget() == null && clone.distanceToSqr(owner) > 6.25;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            owner = null;
            clone.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (owner == null) return;
            clone.getLookControl().setLookAt(owner, 10.0f, clone.getMaxHeadXRot());
            if (--recalc <= 0) {
                recalc = 10;
                if (clone.distanceToSqr(owner) > 400.0) clone.teleportNear(owner);
                else clone.getNavigation().moveTo(owner, 1.25);
            }
        }
    }
}
