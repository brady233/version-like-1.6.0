package com.shinobiarts.jutsu;

import com.shinobiarts.Config;
import com.shinobiarts.fx.Fx;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.Jinchuriki;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.TailedBeast;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.util.Scheduler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** What a tamed jinchuriki can do in the chakra cloak: the Tailed Beast Bomb. */
public final class BeastAttacks {
    private BeastAttacks() {}

    private static boolean ready(ServerPlayer p, NinjaData d, String key) {
        long now = p.level().getGameTime();
        long cd = d.cooldownRemaining(key, now);
        if (cd > 0) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.jin_attack_cooldown", String.format("%.1f", cd / 20.0))
                    .withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        return true;
    }

    /**
     * The Tailed Beast Bomb: black and white chakra gathered into a sphere at the mouth, then fired: it flies at
     * where you look and bursts in a huge blast.
     */
    public static void bomb(ServerPlayer p, NinjaData d) {
        TailedBeast b = d.jin.beast();
        int form = d.jin.form;
        if (b == null || form != Jinchuriki.CLOAK) return;
        String key = "beast_bomb";
        if (!ready(p, d, key)) return;
        float cost = 0.1f * d.maxChakra();
        if (!p.isCreative() && d.getChakra() < cost) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_chakra", (int) d.getChakra(), (int) Math.ceil(cost))
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        if (!p.isCreative()) d.consumeChakra(cost);
        long now = p.level().getGameTime();
        d.setCooldown(key, now + 200);
        ServerLevel level = p.serverLevel();
        float size = 1.0f;
        float damage = Config.f(Config.JIN_BOMB_DAMAGE);
        double radius = 5;
        Vec3 look = p.getLookAngle();
        Vec3 mouth = p.getEyePosition().add(look.scale(1.4)).subtract(0, 0.2, 0);
        Fx.send(level, Fx.Visual.BEAST_BOMB_CHARGE, mouth, mouth, p.getId(), -1, size, 18);
        JutsuUtil.sound(level, mouth, SoundEvents.BEACON_POWER_SELECT, 1.5f, 0.5f);
        JutsuUtil.sound(level, mouth, SoundEvents.WARDEN_SONIC_CHARGE, 1.2f, 0.8f);
        Scheduler.later(18, () -> {
            if (!p.isAlive()) return;
            Vec3 from = p.getEyePosition().add(p.getLookAngle().scale(1.4)).subtract(0, 0.2, 0);
            BlockHitResult hit = JutsuUtil.rayBlock(p, 64);
            Vec3 to = hit.getType() == HitResult.Type.MISS ? p.getEyePosition().add(p.getLookAngle().scale(64)) : hit.getLocation();
            int ticks = MoreJutsu.travel(level, p, from, to, null, 1.8, 1.2 * size, false, false, (e, at) -> {}, end -> {
                for (LivingEntity e : JutsuUtil.inRadius(level, p, end, radius)) {
                    if (e == p) continue;
                    e.invulnerableTime = 0;
                    e.hurt(ModDamage.jutsu(level, p, p), damage);
                    Vec3 away = e.position().subtract(end);
                    JutsuUtil.push(e, (away.lengthSqr() < 1e-4 ? new Vec3(0, 1, 0) : away.normalize()).scale(1.6).add(0, 0.7, 0));
                }
                Fx.send(level, Fx.Visual.BEAST_BLAST, end, end, p.getId(), -1, (float) radius, 34);
                level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, end.x, end.y, end.z, 2, radius * 0.4, radius * 0.3, radius * 0.4, 0);
                JutsuUtil.sound(level, end, SoundEvents.GENERIC_EXPLODE, 4.0f, 0.4f);
                JutsuUtil.sound(level, end, SoundEvents.DRAGON_FIREBALL_EXPLODE, 3.0f, 0.5f);
            }, null);
            Fx.send(level, Fx.Visual.BEAST_BOMB, from, to, p.getId(), -1, size, ticks + 1);
            JutsuUtil.sound(level, from, SoundEvents.WARDEN_SONIC_BOOM, 2.0f, 0.6f);
        });
        ModNetwork.sync(p);
    }
}
