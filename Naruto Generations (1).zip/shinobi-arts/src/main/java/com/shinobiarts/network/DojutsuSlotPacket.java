package com.shinobiarts.network;

import com.shinobiarts.ninja.DojutsuSlot;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Client -> server, creative mode only: the dojutsu slot changed in the creative inventory tab. (Vanilla's creative
 * inventory only sends changes to its own 46 slots, so the extra slot needs its own message, like vanilla's.)
 */
public class DojutsuSlotPacket {
    private final ItemStack stack;

    public DojutsuSlotPacket(ItemStack stack) {
        this.stack = stack;
    }

    public DojutsuSlotPacket(FriendlyByteBuf buf) {
        this.stack = buf.readItem();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeItem(stack);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player == null || !player.isCreative()) return;
        if (!stack.isEmpty() && !DojutsuSlot.accepts(stack)) return;
        NinjaData d = NinjaData.get(player);
        if (d == null || com.shinobiarts.item.ActiveEyeItem.is(d.getDojutsuItem())) return; // switched-on eyes stay put
        d.setDojutsuItem(stack.copyWithCount(Math.min(1, stack.getCount())));
        SharinganManager.updateLook(player);
    }
}
