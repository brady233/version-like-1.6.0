package com.shinobiarts.network;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "9";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            ShinobiArts.id("main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.messageBuilder(ActionPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ActionPacket::encode)
                .decoder(ActionPacket::new)
                .consumerMainThread(ActionPacket::handle)
                .add();
        CHANNEL.messageBuilder(SyncPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncPacket::encode)
                .decoder(SyncPacket::new)
                .consumerMainThread(SyncPacket::handle)
                .add();
        CHANNEL.messageBuilder(BoardPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(BoardPacket::encode)
                .decoder(BoardPacket::new)
                .consumerMainThread(BoardPacket::handle)
                .add();
        CHANNEL.messageBuilder(BoardActionPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(BoardActionPacket::encode)
                .decoder(BoardActionPacket::new)
                .consumerMainThread(BoardActionPacket::handle)
                .add();
        CHANNEL.messageBuilder(EyesPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(EyesPacket::encode)
                .decoder(EyesPacket::new)
                .consumerMainThread(EyesPacket::handle)
                .add();
        CHANNEL.messageBuilder(DojutsuSlotPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(DojutsuSlotPacket::encode)
                .decoder(DojutsuSlotPacket::new)
                .consumerMainThread(DojutsuSlotPacket::handle)
                .add();
        CHANNEL.messageBuilder(ShadowLinkPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(ShadowLinkPacket::encode)
                .decoder(ShadowLinkPacket::new)
                .consumerMainThread(ShadowLinkPacket::handle)
                .add();
        CHANNEL.messageBuilder(MindLinkPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(MindLinkPacket::encode)
                .decoder(MindLinkPacket::new)
                .consumerMainThread(MindLinkPacket::handle)
                .add();
        CHANNEL.messageBuilder(MindInputPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(MindInputPacket::encode)
                .decoder(MindInputPacket::new)
                .consumerMainThread(MindInputPacket::handle)
                .add();
        CHANNEL.messageBuilder(FxPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(FxPacket::encode)
                .decoder(FxPacket::new)
                .consumerMainThread(FxPacket::handle)
                .add();
        CHANNEL.messageBuilder(ShopPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(ShopPacket::encode)
                .decoder(ShopPacket::new)
                .consumerMainThread(ShopPacket::handle)
                .add();
        CHANNEL.messageBuilder(ShopBuyPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ShopBuyPacket::encode)
                .decoder(ShopBuyPacket::new)
                .consumerMainThread(ShopBuyPacket::handle)
                .add();
        CHANNEL.messageBuilder(ConfigSyncPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(ConfigSyncPacket::encode)
                .decoder(ConfigSyncPacket::new)
                .consumerMainThread(ConfigSyncPacket::handle)
                .add();
        CHANNEL.messageBuilder(FtgRenamePacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(FtgRenamePacket::encode)
                .decoder(FtgRenamePacket::new)
                .consumerMainThread(FtgRenamePacket::handle)
                .add();
        CHANNEL.messageBuilder(WaterPrisonPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(WaterPrisonPacket::encode)
                .decoder(WaterPrisonPacket::new)
                .consumerMainThread(WaterPrisonPacket::handle)
                .add();
    }

    /** Sends the player's full ninja data to their own client (for the HUD and menu). */
    public static void sync(ServerPlayer player) {
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        net.minecraft.nbt.CompoundTag tag = data.save();
        // Extras the client needs that aren't the player's own saved data: when the sync happened (for timers)
        // and their team, for the stats menu.
        tag.putLong("SyncTime", player.level().getGameTime());
        tag.put("Team", com.shinobiarts.team.TeamManager.get(player.server).clientInfo(player));
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new SyncPacket(tag));
    }

    public static void toServer(Object message) {
        CHANNEL.sendToServer(message);
    }

    private ModNetwork() {}
}
