package com.shinobiarts.ninja;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/** The eye technique a player has switched on (V cycles through the ones they own). */
public enum Dojutsu {
    NONE("none"),
    SHARINGAN("sharingan"),
    BYAKUGAN("byakugan"),
    RINNEGAN("rinnegan");

    private final String id;

    Dojutsu(String id) {
        this.id = id;
    }

    public String id() {
        return id;
    }

    public static Dojutsu byId(String id) {
        for (Dojutsu d : values()) {
            if (d.id.equals(id)) return d;
        }
        return NONE;
    }

    /** Sharingan stages: 1-3 tomoe, then the Mangekyou. */
    public static final int MANGEKYOU = 4;

    /** "2-Tomoe Sharingan", "Mangekyou Sharingan". */
    public static MutableComponent sharinganName(int stage) {
        return Component.translatable("sharingan.shinobiarts.stage" + Math.max(1, Math.min(MANGEKYOU, stage))).withStyle(ChatFormatting.RED);
    }

    /** "Mangekyou Sharingan (Sasuke)" for the Mangekyou, the usual name below it. */
    public static MutableComponent sharinganName(int stage, MangekyouDesign design) {
        if (stage < MANGEKYOU) return sharinganName(stage);
        return Component.translatable("sharingan.shinobiarts.mangekyou_design", sharinganName(MANGEKYOU), design.displayName())
                .withStyle(ChatFormatting.RED);
    }

    public static MutableComponent byakuganName() {
        return Component.translatable("dojutsu.shinobiarts.hyuga").withStyle(ChatFormatting.AQUA);
    }

    public static MutableComponent rinneganName() {
        return Component.translatable("kekkei_genkai.shinobiarts.rinnegan").withStyle(ChatFormatting.LIGHT_PURPLE);
    }
}
