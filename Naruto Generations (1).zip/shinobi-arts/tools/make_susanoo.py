"""
Builds the Susanoo for the mod from the generator in tools/susanoo (smooth meshes made of swept curves and blobs):

  assets/shinobiarts/susanoo/stage<1-5>.bin     the five meshes (bones + pieces), read by client/SusanooModel.java
  assets/shinobiarts/susanoo/data.json          materials (colour slot, opacity), keyframed actions, sizes
  assets/shinobiarts/textures/entity/susanoo/   one small tiling texture per material (grey, tinted in game, with the
                                                glow map baked in), glow maps for the eyes, crystal and blade, white.png

Binary layout (big-endian, read with DataInputStream):
  "SUSA" int version float scale
  int bones { UTF name, int parent (-1 = none), float pivot x, y, z }          parents always come first
  int pieces { int bone, UTF material, int verts, int tris,
               verts x (float x, y, z), verts x (byte nx, ny, nz: normal * 127), verts x (float u, v),
               tris x 3 indices (unsigned short, or int when verts > 65535) }
Positions are design pixels (16 = 1 block, before the stage's scale); the model faces +Z, its right side is -X.

Run: python3 tools/make_susanoo.py   (needs numpy and Pillow)
"""
import json
import os
import struct
import sys

import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "susanoo"))
import mesh  # noqa: E402

# level of detail for the game: fewer segments than the preview renders (normals are smoothed, so it stays round)
mesh.SPAN_DETAIL, mesh.BLOB_DETAIL, mesh.RING_DETAIL = 0.35, 0.5, 0.55

from anims import REPARENT, to_json  # noqa: E402
from stages import STAGES  # noqa: E402
from textures import MATERIALS, make  # noqa: E402
import weapons  # noqa: E402

ASSETS = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts")
OUT = os.path.join(ASSETS, "susanoo")
TEX = os.path.join(ASSETS, "textures", "entity", "susanoo")
GLOW_PASS = ("eye", "gem", "weapon")  # textures whose glow is drawn as its own full-bright layer
GLOW_BAKE = 0.55                       # how much of the glow map is baked into the other textures


def utf(s):
    b = s.encode("utf-8")
    return struct.pack(">H", len(b)) + b


def write_stage(n, m):
    data = m.export(decimals=3)
    for bone, parent in REPARENT.get(n, {}).items():
        for b in data["bones"]:
            if b["name"] == bone:
                b["parent"] = parent
    names = [b["name"] for b in data["bones"]]
    out = bytearray(b"SUSA" + struct.pack(">if", 1, data["scale"]))
    out += struct.pack(">i", len(names))
    for b in data["bones"]:
        assert b["parent"] is None or names.index(b["parent"]) < names.index(b["name"]), b
        out += utf(b["name"]) + struct.pack(">i", -1 if b["parent"] is None else names.index(b["parent"]))
        out += struct.pack(">3f", *b["pivot"])
    out += struct.pack(">i", len(data["pieces"]))
    tris = 0
    for p in data["pieces"]:
        pos = np.asarray(p["pos"], dtype=">f4")
        nrm = np.clip(np.round(np.asarray(p["nrm"]) * 127), -127, 127).astype(">i1")
        uv = np.asarray(p["uv"], dtype=">f4")
        idx = np.asarray(p["idx"])
        nv, nt = len(pos) // 3, len(idx) // 3
        tris += nt
        out += struct.pack(">i", names.index(p["bone"])) + utf(p["mat"]) + struct.pack(">ii", nv, nt)
        out += pos.tobytes() + nrm.tobytes() + uv.tobytes()
        out += idx.astype(">u2" if nv <= 65535 else ">i4").tobytes()
    open(os.path.join(OUT, f"stage{n}.bin"), "wb").write(bytes(out))
    lo, hi = m.bounds()
    size = (hi - lo) * m.scale / 16
    return tris, {"height": round(float(size[1]), 2), "width": round(float(max(size[0], size[2])), 2)}


def pieces_bytes(data, names):
    out = bytearray()
    out += struct.pack(">i", len(data["pieces"]))
    tris = 0
    for p in data["pieces"]:
        pos = np.asarray(p["pos"], dtype=">f4")
        nrm = np.clip(np.round(np.asarray(p["nrm"]) * 127), -127, 127).astype(">i1")
        uv = np.asarray(p["uv"], dtype=">f4")
        idx = np.asarray(p["idx"])
        nv, nt = len(pos) // 3, len(idx) // 3
        tris += nt
        out += utf(p["bone"]) + utf(p["mat"]) + struct.pack(">ii", nv, nt)
        out += pos.tobytes() + nrm.tobytes() + uv.tobytes()
        out += idx.astype(">u2" if nv <= 65535 else ">i4").tobytes()
    return bytes(out), tris


def write_design(n, design, body):
    """weapons<n>_<design>.bin: the design's hands and weapons, on the body's bones (by name), in the stage's frame:
    "SUSW" int version, then pieces as in the stage files but each with its bone's name instead of its index."""
    meta = body.meta
    t = weapons.build(n, design, meta["joints"], meta["head"])
    S, off = meta["scale"], np.asarray(meta["offset"], float)
    for pc in t.pieces:
        pc["V"] = pc["V"] * S + off
    data = t.export(decimals=3)
    raw, tris = pieces_bytes(data, None)
    open(os.path.join(OUT, f"weapons{n}_{design}.bin"), "wb").write(b"SUSW" + struct.pack(">i", 1) + raw)
    return tris


def bake_textures():
    raw = os.path.join(TEX, "_raw")
    make(raw)
    opacity = {}
    for name, m in MATERIALS.items():
        opacity.setdefault(m["tex"], m["opacity"])
    for tex, op in opacity.items():
        img = np.asarray(Image.open(os.path.join(raw, tex + ".png")).convert("RGBA")).astype(float)
        glow = np.asarray(Image.open(os.path.join(raw, tex + "_glow.png")).convert("L")).astype(float)
        if tex not in GLOW_PASS:
            img[..., :3] = np.minimum(255, img[..., :3] + glow[..., None] * GLOW_BAKE)
            img[..., 3] = np.minimum(255, img[..., 3] + glow * 0.2 / max(op, 0.2))
        Image.fromarray(img.astype(np.uint8), "RGBA").save(os.path.join(TEX, tex + ".png"))
        if tex in GLOW_PASS:
            g = glow.astype(np.uint8)
            Image.fromarray(np.dstack([g, g, g, np.full_like(g, 255)]), "RGBA").save(os.path.join(TEX, tex + "_glow.png"))
    Image.new("RGBA", (16, 16), (255, 255, 255, 255)).save(os.path.join(TEX, "white.png"))
    for f in os.listdir(TEX):
        if f.endswith(".png"):
            json.dump({"texture": {"blur": True}}, open(os.path.join(TEX, f + ".mcmeta"), "w"))
    for f in os.listdir(raw):
        os.remove(os.path.join(raw, f))
    os.rmdir(raw)


def main():
    os.makedirs(OUT, exist_ok=True)
    os.makedirs(TEX, exist_ok=True)
    bake_textures()
    sizes = {}
    for i, f in enumerate(STAGES):
        body = f()
        tris, size = write_stage(i + 1, body)
        sizes[str(i + 1)] = size
        print(f"stage {i + 1}: {tris} triangles, {size['height']} x {size['width']} blocks")
        if getattr(body, "meta", None) is not None:
            for design in weapons.DESIGNS:
                print(f"  {design}: {write_design(i + 1, design, f())} triangles")
    data = {"materials": MATERIALS, "glowPass": list(GLOW_PASS), "anims": to_json(), "sizes": sizes,
            "designs": list(weapons.DESIGNS)}
    json.dump(data, open(os.path.join(OUT, "data.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
