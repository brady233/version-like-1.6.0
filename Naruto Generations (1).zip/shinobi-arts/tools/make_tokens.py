"""
Draws the XP boost token icons (textures/item/xp_boost_<mult>_<minutes>.png, 32x32):
a coin whose middle color shows the multiplier (1.5x teal, 2.5x purple) and whose rim shows the
duration (30 minutes silver, 1 hour gold), with the multiplier and minutes written on it.
Run: python3 tools/make_tokens.py
"""
import os

from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
ITEM = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts", "textures", "item")

# 3x5 pixel font
FONT = {
    "0": ["111", "101", "101", "101", "111"], "1": ["010", "110", "010", "010", "111"],
    "2": ["111", "001", "111", "100", "111"], "3": ["111", "001", "111", "001", "111"],
    "5": ["111", "100", "111", "001", "111"], "6": ["111", "100", "111", "101", "111"],
    ".": ["000", "000", "000", "000", "010"], "x": ["000", "101", "010", "101", "000"],
    "m": ["101", "111", "111", "101", "101"],
}

TOKENS = {
    "xp_boost_1_5x_30m": ("1.5", "30", (40, 170, 140), (200, 206, 214)),
    "xp_boost_1_5x_60m": ("1.5", "60", (40, 170, 140), (236, 188, 64)),
    "xp_boost_2_5x_30m": ("2.5", "30", (150, 60, 200), (200, 206, 214)),
    "xp_boost_2_5x_60m": ("2.5", "60", (150, 60, 200), (236, 188, 64)),
}


def text(img, s, cx, top, color, shadow=(20, 20, 30, 255)):
    widths = [1 if ch == "." else 3 for ch in s]
    total = sum(widths) + len(s) - 1
    x = cx - total // 2
    for ch, w in zip(s, widths):
        glyph = FONT[ch]
        cols = [1] if ch == "." else range(3)
        for gy, row in enumerate(glyph):
            for i, gx in enumerate(cols):
                if row[gx] == "1":
                    img.putpixel((x + i + 1, top + gy + 1), shadow)
                    img.putpixel((x + i, top + gy), color)
        x += w + 1


def token(mult, minutes, inner, rim):
    s = 32 * 8
    big = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(big)
    d.ellipse([s * 0.04, s * 0.04, s * 0.96, s * 0.96], fill=tuple(int(c * 0.55) for c in rim) + (255,))
    d.ellipse([s * 0.07, s * 0.06, s * 0.93, s * 0.92], fill=rim + (255,))
    d.ellipse([s * 0.15, s * 0.14, s * 0.85, s * 0.84], fill=tuple(int(c * 0.6) for c in inner) + (255,))
    d.ellipse([s * 0.17, s * 0.15, s * 0.83, s * 0.8], fill=inner + (255,))
    d.ellipse([s * 0.25, s * 0.18, s * 0.6, s * 0.36], fill=(255, 255, 255, 60))
    img = big.resize((32, 32), Image.LANCZOS)
    text(img, mult + "x", 16, 10, (255, 255, 255, 255))
    text(img, minutes + "m", 16, 17, (255, 240, 170, 255))
    return img


def main():
    for name, (mult, minutes, inner, rim) in TOKENS.items():
        token(mult, minutes, inner, rim).save(os.path.join(ITEM, name + ".png"))
    print(f"{len(TOKENS)} XP boost tokens written")


if __name__ == "__main__":
    main()
