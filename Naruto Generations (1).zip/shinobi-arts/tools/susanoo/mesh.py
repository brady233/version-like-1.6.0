"""
Smooth-mesh builder for the Susanoo (replaces the cube models). Units are design pixels (16 = one block), Y up, the
model faces +Z, its right side is -X; the same layout as the cube version, so the designs keep their shape.

Everything is made of a few primitives, all in absolute coordinates:
  sweep()        a cross-section swept along a smooth curve (bones, ribs, limbs, flames, blades, feathers, plates)
  blob()         a superellipsoid: e = 1 is an ellipsoid, < 1 is a rounded box, > 1 is a diamond (muscles, skulls, gems)
Pieces belong to bones (pivot points only; the rest pose is baked in) so the mod can still animate arms, jaw, wings.
"""
import math

import numpy as np


# Level of detail: samples per curve span and blob segments are scaled by these (the mesh stays smooth because the
# normals are averaged; fewer polygons keep the mod fast).
SPAN_DETAIL = 0.5
BLOB_DETAIL = 0.7
RING_DETAIL = 0.7


def V(*a):
    return np.array(a[0] if len(a) == 1 else a, dtype=float)


def unit(v):
    v = np.asarray(v, dtype=float)
    n = np.linalg.norm(v)
    return v / n if n > 1e-9 else v


def rot(rx=0.0, ry=0.0, rz=0.0):
    """Rotation matrix (degrees), applied X first, then Y, then Z."""
    a, b, c = (math.radians(x) for x in (rx, ry, rz))
    Rx = np.array([[1, 0, 0], [0, math.cos(a), -math.sin(a)], [0, math.sin(a), math.cos(a)]])
    Ry = np.array([[math.cos(b), 0, math.sin(b)], [0, 1, 0], [-math.sin(b), 0, math.cos(b)]])
    Rz = np.array([[math.cos(c), -math.sin(c), 0], [math.sin(c), math.cos(c), 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def lerp(a, b, t):
    return np.asarray(a, float) + (np.asarray(b, float) - np.asarray(a, float)) * t


# ---------------------------------------------------------------- cross-sections (unit size, closed, not repeated)

def circle(n=10):
    return [(math.cos(2 * math.pi * i / n), math.sin(2 * math.pi * i / n)) for i in range(n)]


def superellipse(n=16, p=4.0):
    """A rounded rectangle (p = 4: soft corners; higher = squarer)."""
    out = []
    for i in range(n):
        t = 2 * math.pi * (i + 0.5) / n
        c, s = math.cos(t), math.sin(t)
        out.append((math.copysign(abs(c) ** (2 / p), c), math.copysign(abs(s) ** (2 / p), s)))
    return out


def lens(n=12, sharp=1.6):
    """A leaf/lens shape, pointed at x = +-1 (feathers, flame tongues)."""
    out = []
    for i in range(n):
        t = 2 * math.pi * i / n
        c, s = math.cos(t), math.sin(t)
        out.append((c, math.copysign(abs(s) ** sharp, s)))
    return out


BLADE = [(1.0, 0.0), (0.55, 0.30), (-0.2, 0.62), (-0.85, 0.75), (-1.0, 0.0), (-0.85, -0.75), (-0.2, -0.62), (0.55, -0.30)]
"""A katana's cross-section: thick back (x = -1), sharp edge (x = +1)."""


# ---------------------------------------------------------------- curves

def smooth(points, n=6):
    """Catmull-Rom curve through the points (n samples per span)."""
    P = [np.asarray(p, dtype=float) for p in points]
    if len(P) == 2:
        return [lerp(P[0], P[1], t) for t in np.linspace(0, 1, n + 1)]
    ext = [2 * P[0] - P[1]] + P + [2 * P[-1] - P[-2]]
    out = []
    for i in range(1, len(ext) - 2):
        p0, p1, p2, p3 = ext[i - 1], ext[i], ext[i + 1], ext[i + 2]
        for k in range(n):
            t = k / n
            out.append(0.5 * (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t
                              + (-p0 + 3 * p1 - 3 * p2 + p3) * t ** 3))
    out.append(P[-1])
    return out


def frames(path, hint=None):
    """Tangent, x and y axes at each point. hint: which way the cross-section's x should face (kept as close as
    possible); otherwise the frame is carried along the curve without twisting."""
    n = len(path)
    T = []
    for i in range(n):
        a = path[max(0, i - 1)]
        b = path[min(n - 1, i + 1)]
        T.append(unit(b - a))
    X = []
    if hint is not None:
        h = np.asarray(hint, dtype=float)
        last = None
        for t in T:
            x = h - np.dot(h, t) * t
            if np.linalg.norm(x) < 1e-4:
                x = last if last is not None else unit(np.cross(t, [0, 1, 0]))
            x = unit(x)
            X.append(x)
            last = x
    else:
        up = np.array([0.0, 1.0, 0.0]) if abs(T[0][1]) < 0.9 else np.array([1.0, 0.0, 0.0])
        x = unit(np.cross(up, T[0]))
        for t in T:
            x = unit(x - np.dot(x, t) * t)
            X.append(x)
    Y = [np.cross(t, x) for t, x in zip(T, X)]
    return T, X, Y


# ---------------------------------------------------------------- the model

class Mesh:
    def __init__(self, name, scale=1.0):
        self.name = name
        self.scale = scale          # render scale applied in game (design px -> blocks)
        self.bones = {}
        self.order = []
        self.pieces = []

    def bone(self, name, parent=None, pivot=(0, 0, 0)):
        if name not in self.bones:
            assert parent is None or parent in self.bones, parent
            self.bones[name] = {"name": name, "parent": parent, "pivot": [float(v) for v in pivot]}
            self.order.append(name)
        return name

    def add(self, bone, mat, verts, faces, uvs):
        assert bone in self.bones, bone
        self.pieces.append({"bone": bone, "mat": mat, "V": np.asarray(verts, dtype=float),
                            "F": np.asarray(faces, dtype=np.int64), "UV": np.asarray(uvs, dtype=float)})

    def triangles(self):
        return sum(len(p["F"]) for p in self.pieces)

    def vertices(self):
        return sum(len(p["V"]) for p in self.pieces)

    def bounds(self):
        allv = np.concatenate([p["V"] for p in self.pieces])
        return allv.min(axis=0), allv.max(axis=0)

    # ------------------------------------------------------------ primitives

    def sweep(self, bone, mat, points, size, profile=None, hint=None, cap0="round", cap1="round", n=6, uv_len=24.0,
              twist=0.0, resample=True):
        """Sweeps a cross-section along a smooth curve through points.
        size: (w, h) or a function t -> (w, h) giving the full width/height at each point along the curve (t = 0..1).
        cap0/cap1: "round" (domed), "point" (pinched to a tip), "flat", or None (open)."""
        profile = profile or circle(10)
        if len(profile) >= 10 and all(abs(math.hypot(*q) - 1) < 1e-6 for q in profile):
            profile = circle(max(6, round(len(profile) * RING_DETAIL)))     # plain round tubes: fewer sides
        n = max(1, round(n * SPAN_DETAIL))
        path = smooth(points, n) if resample else [np.asarray(p, float) for p in points]
        T, X, Y = frames(path, hint)
        seg = [np.linalg.norm(path[i + 1] - path[i]) for i in range(len(path) - 1)]
        total = max(1e-6, sum(seg))
        dist = np.concatenate([[0], np.cumsum(seg)])
        fn = size if callable(size) else (lambda t, s=size: s)

        stations = []   # (center, x axis, y axis, half width, half height, u)
        for i, p in enumerate(path):
            t = dist[i] / total
            w, h = fn(t)
            a = math.radians(twist * t)
            x = X[i] * math.cos(a) + Y[i] * math.sin(a)
            y = np.cross(T[i], x)
            stations.append((p, x, y, w / 2, h / 2, dist[i] / uv_len))

        def dome(end, sign, tangent):
            c, x, y, hw, hh, u = end
            r = min(hw, hh) if min(hw, hh) > 0 else max(hw, hh)
            out = []
            for k in (1, 2):
                a = k / 3 * math.pi / 2
                out.append((c + tangent * sign * r * math.sin(a), x, y, hw * math.cos(a), hh * math.cos(a), u + sign * r * math.sin(a) / uv_len))
            return out, c + tangent * sign * r, u + sign * r / uv_len

        start_apex = end_apex = None
        if cap0 == "round":
            pre, start_apex, su = dome(stations[0], -1, T[0])
            stations = list(reversed(pre)) + stations
            start_apex = (start_apex, su)
        elif cap0 in ("point", "flat"):
            start_apex = (stations[0][0], stations[0][5])
        if cap1 == "round":
            post, end_apex, eu = dome(stations[-1], 1, T[-1])
            stations = stations + post
            end_apex = (end_apex, eu)
        elif cap1 in ("point", "flat"):
            end_apex = (stations[-1][0], stations[-1][5])

        k = len(profile)
        verts, uvs, faces = [], [], []
        for (c, x, y, hw, hh, u) in stations:
            for j in range(k + 1):                       # seam vertex repeated for the texture
                px, py = profile[j % k]
                verts.append(c + x * px * hw + y * py * hh)
                uvs.append((u, j / k))
        ring = k + 1
        for s in range(len(stations) - 1):
            for j in range(k):
                a = s * ring + j
                b = a + ring
                faces.append((a, a + 1, b))
                faces.append((a + 1, b + 1, b))
        if start_apex is not None:
            ci = len(verts)
            verts.append(start_apex[0])
            uvs.append((start_apex[1], 0.5))
            for j in range(k):
                faces.append((ci, j + 1, j))
        if end_apex is not None:
            ci = len(verts)
            verts.append(end_apex[0])
            uvs.append((end_apex[1], 0.5))
            base = (len(stations) - 1) * ring
            for j in range(k):
                faces.append((ci, base + j, base + j + 1))
        self.add(bone, mat, verts, faces, uvs)

    def blob(self, bone, mat, center, size, R=None, e=(1.0, 1.0), seg=(20, 12), v_range=(-90, 90), uv_len=24.0, flat=False):
        """A superellipsoid centred at center, full size (w, h, d), turned by R. e = (latitude, longitude) exponents:
        1 = ellipsoid, 0.3 = rounded box, 2 = diamond. v_range limits latitudes (e.g. (0, 90) for a dome)."""
        nu, nv = (seg if flat else (max(8, round(seg[0] * BLOB_DETAIL)), max(4, round(seg[1] * BLOB_DETAIL))))
        rx, ry, rz = (s / 2 for s in size)
        R = np.eye(3) if R is None else R
        c = np.asarray(center, dtype=float)
        f = lambda w, ex: math.copysign(abs(w) ** ex, w)
        verts, uvs, faces = [], [], []
        v0, v1 = (math.radians(a) for a in v_range)
        for i in range(nv + 1):
            v = v0 + (v1 - v0) * i / nv
            for j in range(nu + 1):
                u = 2 * math.pi * j / nu
                p = np.array([rx * f(math.cos(v), e[0]) * f(math.sin(u), e[1]), ry * f(math.sin(v), e[0]),
                              rz * f(math.cos(v), e[0]) * f(math.cos(u), e[1])])
                verts.append(c + R @ p)
                uvs.append((j / nu * (rx + rz) * 3.2 / uv_len, i / nv * ry * 3.2 / uv_len))
        ring = nu + 1
        for i in range(nv):
            for j in range(nu):
                a = i * ring + j
                b = a + ring
                faces.append((a, a + 1, b))
                faces.append((a + 1, b + 1, b))
        if v_range[0] > -90:                          # close an open bottom
            ci = len(verts)
            verts.append(c + R @ np.array([0, ry * f(math.sin(v0), e[0]), 0]))
            uvs.append((0.5, 0))
            for j in range(nu):
                faces.append((ci, j + 1, j))
        self.add(bone, mat, verts, faces, uvs)
        if flat:
            self.pieces[-1]["flat"] = True

    def mirror(self, start):
        """Copies every piece added since index start to the other side (x -> -x), bones renamed _r <-> _l."""
        for p in self.pieces[start:len(self.pieces)]:
            b = p["bone"]
            nb = b[:-2] + "_l" if b.endswith("_r") else (b[:-2] + "_r" if b.endswith("_l") else b)
            if nb not in self.bones:
                src = self.bones[b]
                piv = src["pivot"]
                par = src["parent"]
                if par and par.endswith("_r"):
                    par = par[:-2] + "_l"
                elif par and par.endswith("_l"):
                    par = par[:-2] + "_r"
                self.bone(nb, par, (-piv[0], piv[1], piv[2]))
            v = p["V"].copy()
            v[:, 0] *= -1
            f = p["F"][:, ::-1].copy()
            self.pieces.append({"bone": nb, "mat": p["mat"], "V": v, "F": f, "UV": p["UV"].copy()})

    # ------------------------------------------------------------ export

    def export(self, decimals=2):
        """JSON-ready dict: bones, and per piece positions / smooth normals / uvs / triangle indices."""
        pieces = []
        for p in self.pieces:
            Vv, F = p["V"], p["F"]
            if p.get("flat"):                         # faceted (the gem): every triangle gets its own vertices
                tri = Vv[F]
                fn = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
                fn = fn / np.maximum(np.linalg.norm(fn, axis=1, keepdims=True), 1e-9)
                uv = p["UV"][F].reshape(-1, 2)
                pieces.append({"bone": p["bone"], "mat": p["mat"], "pos": np.round(tri.reshape(-1, 3), decimals).ravel().tolist(),
                               "nrm": np.round(np.repeat(fn, 3, axis=0), 3).ravel().tolist(), "uv": np.round(uv, 3).ravel().tolist(),
                               "idx": list(range(len(F) * 3))})
                continue
            N = np.zeros_like(Vv)
            tri = Vv[F]
            fn = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
            for k in range(3):
                np.add.at(N, F[:, k], fn)
            # vertices at the same spot (texture seams, caps) share one normal so the surface stays smooth
            keys = {}
            for i, v in enumerate(np.round(Vv, 3)):
                keys.setdefault(tuple(v), []).append(i)
            for idx in keys.values():
                if len(idx) > 1:
                    N[idx] = N[idx].sum(axis=0)
            L = np.linalg.norm(N, axis=1, keepdims=True)
            N = N / np.where(L < 1e-9, 1, L)
            pieces.append({"bone": p["bone"], "mat": p["mat"],
                           "pos": np.round(Vv, decimals).ravel().tolist(),
                           "nrm": np.round(N, 3).ravel().tolist(),
                           "uv": np.round(p["UV"], 3).ravel().tolist(),
                           "idx": F.ravel().tolist()})
        return {"name": self.name, "scale": self.scale, "bones": [self.bones[n] for n in self.order], "pieces": pieces}
